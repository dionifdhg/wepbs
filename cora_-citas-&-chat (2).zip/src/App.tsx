/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Home, MessageCircle, User, Search, Sparkles, LogOut, Plus, Play, Share2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Pages - We'll implement these in following steps
import Landing from './pages/Landing';
import Discover from './pages/Discover';
import Matches from './pages/Matches';
import Chat from './pages/Chat';
import Profile from './pages/Profile';
import Onboarding from './pages/Onboarding';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user, profile, loading } = useAuth();
  const location = useLocation();

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-50">
      <motion.div
        animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="w-12 h-12 bg-brand rounded-full flex items-center justify-center text-white shadow-xl shadow-brand/30"
      >
        <Sparkles fill="currentColor" size={24} />
      </motion.div>
    </div>
  );

  if (!user) return <Navigate to="/" state={{ from: location }} replace />;
  
  // If user is logged in but has no profile data, show onboarding
  // unless they are already on onboarding
  if (!profile && location.pathname !== '/onboarding') {
    return <Navigate to="/onboarding" replace />;
  }

  return <>{children}</>;
}

function BottomNav() {
  const location = useLocation();
  const { profile } = useAuth();
  
  if (!profile) return null;

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Cora App',
        text: '¡Mira esta aplicación!',
        url: window.location.origin
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(window.location.origin);
      alert('¡Enlace de la app copiado!');
    }
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-zinc-100 h-16 px-4 flex items-center justify-around z-50">
      <Link
        to="/discover"
        className={`flex flex-col items-center gap-1 transition-all ${
          location.pathname.startsWith('/discover') ? 'text-zinc-950' : 'text-zinc-300 hover:text-zinc-500'
        }`}
      >
        <Home size={26} strokeWidth={location.pathname.startsWith('/discover') ? 2.5 : 2} />
      </Link>

      <Link
        to="/matches"
        className={`flex flex-col items-center gap-1 transition-all ${
          location.pathname.startsWith('/matches') ? 'text-zinc-950' : 'text-zinc-300 hover:text-zinc-500'
        }`}
      >
        <MessageCircle size={26} strokeWidth={location.pathname.startsWith('/matches') ? 2.5 : 2} />
      </Link>

      <button
        onClick={handleShare}
        className="flex flex-col items-center gap-1 transition-all text-zinc-300 hover:text-zinc-950 active:scale-90"
      >
        <Share2 size={26} strokeWidth={2} />
      </button>

      <Link
        to="/profile"
        className={`flex flex-col items-center gap-1 transition-all ${
          location.pathname.startsWith('/profile') ? 'text-zinc-950' : 'text-zinc-300 hover:text-zinc-500'
        }`}
      >
        <User size={26} strokeWidth={location.pathname.startsWith('/profile') ? 2.5 : 2} />
      </Link>
    </nav>
  );
}

function BackgroundAnimation() {
  return (
    <div className="fixed inset-0 -z-10 bg-zinc-50 overflow-hidden pointer-events-none">
      {/* Background Blobs */}
      <motion.div 
        animate={{ 
          x: [0, 40, 0], 
          y: [0, 50, 0],
          scale: [1, 1.1, 1] 
        }}
        transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
        className="absolute -top-[10%] -left-[10%] w-[50%] h-[50%] bg-brand/5 blur-[120px] rounded-full"
      />
      <motion.div 
        animate={{ 
          x: [0, -30, 0], 
          y: [0, 20, 0],
          scale: [1, 1.2, 1] 
        }}
        transition={{ duration: 12, repeat: Infinity, ease: "linear" }}
        className="absolute top-[20%] -right-[15%] w-[40%] h-[40%] bg-accent/5 blur-[100px] rounded-full"
      />
      <motion.div 
        animate={{ 
          x: [0, 60, 0], 
          y: [0, -40, 0],
          scale: [1, 0.9, 1] 
        }}
        transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
        className="absolute -bottom-[10%] left-[20%] w-[60%] h-[60%] bg-brand-secondary/5 blur-[140px] rounded-full"
      />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,transparent_0%,rgba(255,255,255,0.4)_100%)] opacity-20" />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen pb-20 md:pb-0 relative">
          <BackgroundAnimation />
          <AnimatePresence mode="wait">
            <Routes>
              <Route path="/" element={<Landing />} />
              <Route path="/onboarding" element={<PrivateRoute><Onboarding /></PrivateRoute>} />
              <Route path="/discover" element={<PrivateRoute><Discover /></PrivateRoute>} />
              <Route path="/matches" element={<PrivateRoute><Matches /></PrivateRoute>} />
              <Route path="/matches/:matchId" element={<PrivateRoute><Chat /></PrivateRoute>} />
              <Route path="/profile" element={<PrivateRoute><Profile /></PrivateRoute>} />
              <Route path="*" element={<Navigate to="/discover" />} />
            </Routes>
          </AnimatePresence>
          <BottomNav />
        </div>
      </Router>
    </AuthProvider>
  );
}
