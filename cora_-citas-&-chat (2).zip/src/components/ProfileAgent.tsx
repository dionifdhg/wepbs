import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, X, Send, Bot, Wand2, Lightbulb } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';
import Markdown from 'react-markdown';

interface ProfileAgentProps {
  profile: any;
  onUpdateBio: (newBio: string) => void;
}

export default function ProfileAgent({ profile, onUpdateBio }: ProfileAgentProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'assistant'; content: string }[]>([
    { role: 'assistant', content: '¡Hola! Soy Cora, tu asistente de perfil. ¿En qué puedo ayudarte hoy? Puedo analizar tu biografía o darte ideas para tus fotos.' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSend = async (text: string = input) => {
    if (!text.trim() || isLoading) return;
    
    const newMessages = [...messages, { role: 'user' as const, content: text }];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      
      const context = `
        Eres Cora, una experta en dating apps y coach de relaciones para la app "Cora".
        El perfil actual del usuario es:
        Nombre: ${profile.displayName}
        Edad: ${profile.age}
        Bio actual: "${profile.bio || 'Sin biografía'}"
        Número de fotos: ${profile.photos?.length || 0}
        Género: ${profile.gender}
        
        Tu objetivo es ayudar al usuario a tener un perfil más atractivo y auténtico. 
        Sé amigable, directa y usa un tono moderno/joven (como Badoo/Tinder).
        Si sugieres una nueva biografía, hazla divertida y que invite a la conversación.
      `;

      const prompt = `${context}\n\nHistorial:\n${messages.map(m => `${m.role}: ${m.content}`).join('\n')}\nuser: ${text}`;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt
      });

      setMessages([...newMessages, { role: 'assistant' as const, content: response.text || '' }]);
    } catch (error) {
      console.error('Error in Cora AI:', error);
      setMessages([...newMessages, { role: 'assistant' as const, content: 'Lo siento, he tenido un pequeño error de conexión. ¡Prueba otra vez!' }]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickActions = [
    { label: 'Analiza mi bio', icon: Wand2, action: 'Analiza mi biografía actual y dime qué puedo mejorar.' },
    { label: 'Ideas de fotos', icon: Lightbulb, action: '¿Qué tipo de fotos debería subir para tener más matches?' },
  ];

  return (
    <>
      {/* Float Button */}
      <motion.button
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        onClick={() => setIsOpen(true)}
        className="fixed bottom-24 right-6 w-14 h-14 bg-brand text-white rounded-full flex items-center justify-center shadow-xl shadow-brand/40 z-50 border-2 border-white/20"
      >
        <Sparkles size={24} />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-[110] flex items-end md:items-center md:justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            
            <motion.div
              initial={{ y: '100%', opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: '100%', opacity: 0 }}
              className="relative w-full max-w-lg h-[80vh] bg-white rounded-t-[2.5rem] md:rounded-[2.5rem] flex flex-col overflow-hidden shadow-2xl"
            >
              {/* Header */}
              <div className="p-6 border-b border-zinc-100 flex items-center justify-between bg-white sticky top-0 z-10">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-brand rounded-xl flex items-center justify-center text-white shadow-lg shadow-brand/20">
                    <Bot size={20} />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-lg">Cora AI Coach</h3>
                    <div className="flex items-center gap-1">
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                      <span className="text-[10px] text-zinc-400 uppercase font-bold tracking-widest">En línea</span>
                    </div>
                  </div>
                </div>
                <button onClick={() => setIsOpen(false)} className="p-2 text-zinc-400 hover:text-zinc-900 transition-colors">
                  <X size={24} />
                </button>
              </div>

              {/* Chat Body */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-zinc-50/50">
                {messages.map((m, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div className={`max-w-[85%] p-4 rounded-3xl text-sm ${
                      m.role === 'user' 
                        ? 'bg-brand text-white rounded-tr-none' 
                        : 'bg-white border border-zinc-100 text-zinc-700 rounded-tl-none shadow-sm'
                    }`}>
                      <Markdown>{m.content}</Markdown>
                    </div>
                  </motion.div>
                ))}
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-white border border-zinc-100 p-4 rounded-3xl rounded-tl-none shadow-sm flex gap-1">
                      <div className="w-1.5 h-1.5 bg-brand rounded-full animate-bounce" />
                      <div className="w-1.5 h-1.5 bg-brand rounded-full animate-bounce [animation-delay:0.2s]" />
                      <div className="w-1.5 h-1.5 bg-brand rounded-full animate-bounce [animation-delay:0.4s]" />
                    </div>
                  </div>
                )}
              </div>

              {/* Footer / Input */}
              <div className="p-6 bg-white border-t border-zinc-100">
                {messages.length < 3 && (
                  <div className="flex gap-2 overflow-x-auto pb-4 hide-scrollbar">
                    {quickActions.map((action, i) => (
                      <button
                        key={i}
                        onClick={() => handleSend(action.action)}
                        className="flex items-center gap-2 px-4 py-2 bg-zinc-50 border border-zinc-100 rounded-full text-xs font-bold text-zinc-500 whitespace-nowrap hover:bg-brand/5 hover:border-brand/20 hover:text-brand transition-all"
                      >
                        <action.icon size={14} />
                        {action.label}
                      </button>
                    ))}
                  </div>
                )}
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Pregúntale algo a Cora..."
                    className="flex-1 p-4 bg-zinc-100 border border-transparent rounded-2xl outline-none focus:border-brand transition-colors text-sm"
                  />
                  <button
                    onClick={() => handleSend()}
                    disabled={!input.trim() || isLoading}
                    className="w-12 h-12 bg-brand text-white rounded-2xl flex items-center justify-center disabled:opacity-50 active:scale-90 transition-transform shadow-lg shadow-brand/20"
                  >
                    <Send size={20} />
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
