import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Phone, PhoneOff, Video, VideoOff, Mic, MicOff, Camera, CameraOff, X } from 'lucide-react';
import { db } from '../lib/firebase';
import { 
  collection, 
  doc, 
  onSnapshot, 
  addDoc, 
  updateDoc, 
  setDoc, 
  getDoc, 
  deleteDoc,
  serverTimestamp,
  query,
  where
} from 'firebase/firestore';

interface CallOverlayProps {
  matchId: string;
  user: any;
  otherUser: any;
  onClose: () => void;
  type: 'video' | 'voice';
  isIncoming?: boolean;
  callId?: string;
}

const servers = {
  iceServers: [
    {
      urls: ['stun:stun1.l.google.com:19302', 'stun:stun2.l.google.com:19302'],
    },
  ],
  iceCandidatePoolSize: 10,
};

export default function CallOverlay({ matchId, user, otherUser, onClose, type, isIncoming, callId }: CallOverlayProps) {
  const [callStatus, setCallStatus] = useState<'requesting' | 'ringing' | 'connected' | 'ended'> (isIncoming ? 'ringing' : 'requesting');
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOff, setIsCameraOff] = useState(type === 'voice');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  const pc = useRef<RTCPeerConnection | null>(null);
  const localStream = useRef<MediaStream | null>(null);
  const remoteStream = useRef<MediaStream | null>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const callDocRef = useRef<any>(null);

  useEffect(() => {
    const initializeStreams = async () => {
      try {
        localStream.current = await navigator.mediaDevices.getUserMedia({
          video: type === 'video',
          audio: true,
        });

        if (localVideoRef.current) {
          localVideoRef.current.srcObject = localStream.current;
        }

        remoteStream.current = new MediaStream();
        if (remoteVideoRef.current) {
          remoteVideoRef.current.srcObject = remoteStream.current;
        }

        if (!isIncoming) {
          await startCall();
        } else if (callId) {
          // If we have callId, we can pre-set the doc ref
          callDocRef.current = doc(db, 'matches', matchId, 'calls', callId);
          
          // Listen for call being ended by caller before we even accept
          const unsub = onSnapshot(callDocRef.current, (snapshot) => {
            if (snapshot.data()?.status === 'ended') {
              cleanup();
              unsub();
            }
          });
        }
      } catch (err) {
        console.error('Failed to get media devices:', err);
        setErrorMessage('No se pudo acceder a la cámara o micrófono');
        setTimeout(onClose, 3000);
      }
    };

    initializeStreams();

    return () => {
      cleanup();
    };
  }, []);

  const setupPeerConnection = () => {
    pc.current = new RTCPeerConnection(servers);

    // Add local tracks to peer connection
    localStream.current?.getTracks().forEach((track) => {
      if (localStream.current) {
        pc.current?.addTrack(track, localStream.current);
      }
    });

    // Handle remote tracks
    pc.current.ontrack = (event) => {
      event.streams[0].getTracks().forEach((track) => {
        remoteStream.current?.addTrack(track);
      });
    };

    pc.current.oniceconnectionstatechange = () => {
      if (pc.current?.iceConnectionState === 'disconnected') {
        cleanup();
      }
    };
  };

  const startCall = async () => {
    const callsCollection = collection(db, 'matches', matchId, 'calls');
    callDocRef.current = doc(callsCollection);

    setupPeerConnection();

    if (!pc.current) return;

    // Push local ICE candidates to Firestore
    pc.current.onicecandidate = (event) => {
      if (event.candidate && callDocRef.current) {
        const candidatesCol = collection(callDocRef.current, 'callerCandidates');
        addDoc(candidatesCol, event.candidate.toJSON());
      }
    };

    // Create Offer
    const offerDescription = await pc.current.createOffer();
    await pc.current.setLocalDescription(offerDescription);

    const offer = {
      sdp: offerDescription.sdp,
      type: offerDescription.type,
    };

    await setDoc(callDocRef.current, {
      offer,
      callerUid: user.uid,
      type,
      status: 'requesting',
      createdAt: serverTimestamp(),
    });

    // Listen for Answer
    onSnapshot(callDocRef.current, (snapshot) => {
      const data = snapshot.data();
      if (!pc.current?.currentRemoteDescription && data?.answer) {
        const answerDescription = new RTCSessionDescription(data.answer);
        pc.current.setRemoteDescription(answerDescription);
        setCallStatus('connected');
      }
      if (data?.status === 'ended' && callStatus !== 'ended') {
        cleanup();
      }
    });

    // Listen for remote ICE candidates
    onSnapshot(collection(callDocRef.current, 'calleeCandidates'), (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === 'added') {
          const data = change.doc.data();
          pc.current?.addIceCandidate(new RTCIceCandidate(data));
        }
      });
    });
  };

  const acceptCall = async () => {
    if (!callId || !localStream.current) return;

    callDocRef.current = doc(db, 'matches', matchId, 'calls', callId);
    setupPeerConnection();

    if (!pc.current) return;

    pc.current.onicecandidate = (event) => {
      if (event.candidate && callDocRef.current) {
        const candidatesCol = collection(callDocRef.current, 'calleeCandidates');
        addDoc(candidatesCol, event.candidate.toJSON());
      }
    };

    const callSnapshot = await getDoc(callDocRef.current);
    const callData = callSnapshot.data() as any;
    
    if (!callData || callData.status === 'ended') {
      setErrorMessage('La llamada ha finalizado');
      setTimeout(onClose, 2000);
      return;
    }

    const offerDescription = callData.offer;
    await pc.current.setRemoteDescription(new RTCSessionDescription(offerDescription));

    const answerDescription = await pc.current.createAnswer();
    await pc.current.setLocalDescription(answerDescription);

    const answer = {
      type: answerDescription.type,
      sdp: answerDescription.sdp,
    };

    await updateDoc(callDocRef.current, { answer, status: 'connected' });

    // Listen for remote ICE candidates
    onSnapshot(collection(callDocRef.current, 'callerCandidates'), (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === 'added') {
          const data = change.doc.data();
          pc.current?.addIceCandidate(new RTCIceCandidate(data));
        }
      });
    });

    // Listen for end call
    onSnapshot(callDocRef.current, (snapshot) => {
      if (snapshot.data()?.status === 'ended' && callStatus !== 'ended') {
        cleanup();
      }
    });

    setCallStatus('connected');
  };

  const cleanup = () => {
    if (callStatus === 'ended') return;

    localStream.current?.getTracks().forEach(t => t.stop());
    pc.current?.close();
    
    if (callDocRef.current) {
      updateDoc(callDocRef.current, { status: 'ended' }).catch(() => {});
    }
    
    setCallStatus('ended');
    setTimeout(onClose, 1000);
  };

  const toggleMute = () => {
    if (localStream.current) {
      const audioTrack = localStream.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMuted(!audioTrack.enabled);
      }
    }
  };

  const toggleCamera = () => {
    if (localStream.current && type === 'video') {
      const videoTrack = localStream.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsCameraOff(!videoTrack.enabled);
      }
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] bg-zinc-900 flex flex-col items-center justify-center p-6"
    >
      {/* Background/Remote Video */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        {type === 'video' ? (
          <video 
            ref={remoteVideoRef} 
            autoPlay 
            playsInline 
            className="w-full h-full object-cover opacity-80"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-zinc-800">
             <img 
              src={otherUser?.photos?.[0] || `https://api.dicebear.com/7.x/avataaars/svg?seed=${otherUser?.uid}`} 
              alt=""
              className="w-32 h-32 rounded-full border-4 border-brand/20 blur-sm absolute scale-150 opacity-20"
            />
            <div className="relative z-10 flex flex-col items-center">
              <img 
                src={otherUser?.photos?.[0] || `https://api.dicebear.com/7.x/avataaars/svg?seed=${otherUser?.uid}`} 
                alt=""
                className="w-32 h-32 rounded-full border-4 border-white/10 mb-6 object-cover"
              />
              <h2 className="text-2xl font-bold text-white mb-2">{otherUser?.displayName}</h2>
              <p className="text-zinc-400 font-medium">
                {callStatus === 'requesting' ? 'Llamando...' : callStatus === 'ringing' ? 'Llamada entrante...' : 'Conectado'}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Local Video Overlay */}
      {type === 'video' && (
        <div className="absolute top-8 right-8 w-32 h-48 bg-zinc-800 rounded-2xl overflow-hidden shadow-2xl border-2 border-white/10 z-20">
          <video 
            ref={localVideoRef} 
            autoPlay 
            muted 
            playsInline 
            className={`w-full h-full object-cover ${isCameraOff ? 'hidden' : ''}`}
          />
          {isCameraOff && (
            <div className="w-full h-full flex items-center justify-center text-zinc-600">
              <CameraOff size={24} />
            </div>
          )}
        </div>
      )}

      {/* Controls */}
      <div className="absolute bottom-12 left-0 right-0 z-30 flex flex-col items-center gap-8">
        {callStatus === 'ringing' && isIncoming ? (
          <div className="flex gap-12">
            <button 
              onClick={cleanup}
              className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center text-white shadow-xl active:scale-90 transition-transform"
            >
              <PhoneOff size={28} />
            </button>
            <button 
              onClick={acceptCall}
              className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center text-white shadow-xl animate-bounce active:scale-90 transition-transform"
            >
              <Phone size={28} />
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-6">
            <button 
              onClick={toggleMute}
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${isMuted ? 'bg-white text-zinc-900' : 'bg-white/10 text-white backdrop-blur-md'}`}
            >
              {isMuted ? <MicOff size={24} /> : <Mic size={24} />}
            </button>
            
            <button 
              onClick={cleanup}
              className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center text-white shadow-xl active:scale-90 transition-transform"
            >
              <PhoneOff size={28} />
            </button>

            {type === 'video' && (
              <button 
                onClick={toggleCamera}
                className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${isCameraOff ? 'bg-white text-zinc-900' : 'bg-white/10 text-white backdrop-blur-md'}`}
              >
                {isCameraOff ? <CameraOff size={24} /> : <Camera size={24} />}
              </button>
            )}
          </div>
        )}
      </div>

      {callStatus === 'ended' && (
        <div className="absolute inset-0 bg-zinc-900 flex items-center justify-center z-50">
          <p className="text-xl font-bold text-white">Llamada finalizada</p>
        </div>
      )}

      {errorMessage && (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-red-500 text-white px-6 py-4 rounded-2xl shadow-2xl z-[110] text-center">
          <p className="font-bold">{errorMessage}</p>
        </div>
      )}
    </motion.div>
  );
}
