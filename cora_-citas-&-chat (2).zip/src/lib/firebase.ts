import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDocFromServer } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth();

// Test connection to Firestore
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log("Firestore connection check: Success");
  } catch (error: any) {
    if (error?.message?.includes('the client is offline')) {
      console.error("Firestore connection check: Client is offline. Check Firebase configuration.");
    } else if (error?.code === 'permission-denied' || error?.message?.includes('permissions')) {
      // Permission denied actually means we HAVE a connection, 
      // but the rule doesn't allow reading this specific document.
      console.log("Firestore connection check: Connected (Permission Denied as expected)");
    } else {
      console.error("Firestore connection check: Failed", error);
    }
  }
}
testConnection();
