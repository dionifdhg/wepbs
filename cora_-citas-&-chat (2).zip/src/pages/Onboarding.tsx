import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Camera, ChevronRight, Sparkles } from 'lucide-react';
import { Navigate } from 'react-router-dom';

export default function Onboarding() {
  const { user, profile, refreshProfile } = useAuth();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    displayName: user?.displayName || '',
    age: 25,
    bio: '',
    gender: 'other',
    interestedIn: 'both',
    photos: [] as string[]
  });
  const [isSaving, setIsSaving] = useState(false);

  if (profile) return <Navigate to="/discover" />;

  const handleSubmit = async () => {
    if (!user) return;
    setIsSaving(true);
    try {
      await setDoc(doc(db, 'users', user.uid), {
        ...formData,
        uid: user.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      await refreshProfile();
    } catch (error) {
      console.error('Error saving profile:', error);
      setIsSaving(false);
    }
  };

  const nextStep = () => setStep(step + 1);

  return (
    <div className="min-h-screen bg-zinc-50 px-6 py-12 flex flex-col items-center">
      <div className="max-w-md w-full">
        <div className="flex items-center gap-2 mb-12 justify-center">
          <div className="w-8 h-8 bg-brand rounded-lg flex items-center justify-center text-white">
            <Sparkles fill="currentColor" size={16} />
          </div>
          <span className="text-xl font-display font-bold">Cora</span>
        </div>

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div>
                <h1 className="text-3xl font-bold mb-2">Completar Perfil</h1>
                <p className="text-zinc-500">¿Cómo te llamas y qué edad tienes?</p>
              </div>

              <div className="space-y-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">Nombre</label>
                  <input
                    type="text"
                    value={formData.displayName}
                    onChange={(e) => setFormData({ ...formData, displayName: e.target.value })}
                    className="w-full px-6 py-4 rounded-2xl bg-white border border-zinc-200 outline-none focus:border-brand transition-colors"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">Edad</label>
                  <input
                    type="number"
                    value={formData.age}
                    onChange={(e) => setFormData({ ...formData, age: parseInt(e.target.value) || 18 })}
                    className="w-full px-6 py-4 rounded-2xl bg-white border border-zinc-200 outline-none focus:border-brand transition-colors"
                  />
                </div>
              </div>

              <button
                onClick={nextStep}
                disabled={!formData.displayName || !formData.age}
                className="w-full bg-zinc-900 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 disabled:opacity-50"
              >
                Siguiente <ChevronRight size={20} />
              </button>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div>
                <h1 className="text-3xl font-bold mb-2">Tu Biografía</h1>
                <p className="text-zinc-500">Cuéntanos un poco sobre ti.</p>
              </div>

              <textarea
                value={formData.bio}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                placeholder="Me gusta viajar, los gatos y programar..."
                className="w-full h-40 px-6 py-4 rounded-2xl bg-white border border-zinc-200 outline-none focus:border-brand transition-colors resize-none"
              />

              <button
                onClick={nextStep}
                className="w-full bg-zinc-900 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2"
              >
                Siguiente <ChevronRight size={20} />
              </button>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-8"
            >
              <div>
                <h1 className="text-3xl font-bold mb-2">Intereses</h1>
                <p className="text-zinc-500">¿Qué estás buscando?</p>
              </div>

              <div className="space-y-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-400 text-center block">Me identifico como...</label>
                  <div className="grid grid-cols-3 gap-2">
                    {['male', 'female', 'other'].map((g) => (
                      <button
                        key={g}
                        onClick={() => setFormData({ ...formData, gender: g })}
                        className={`py-3 rounded-xl border text-sm font-medium transition-all ${
                          formData.gender === g ? 'bg-brand text-white border-brand' : 'bg-white text-zinc-600 border-zinc-200'
                        }`}
                      >
                        {g === 'male' ? 'Hombre' : g === 'female' ? 'Mujer' : 'Otro'}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-400 text-center block">Me interesa...</label>
                  <div className="grid grid-cols-3 gap-2">
                    {['male', 'female', 'both'].map((i) => (
                      <button
                        key={i}
                        onClick={() => setFormData({ ...formData, interestedIn: i })}
                        className={`py-3 rounded-xl border text-sm font-medium transition-all ${
                          formData.interestedIn === i ? 'bg-brand text-white border-brand' : 'bg-white text-zinc-600 border-zinc-200'
                        }`}
                      >
                        {i === 'male' ? 'Hombres' : i === 'female' ? 'Mujeres' : 'Ambos'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <button
                onClick={handleSubmit}
                disabled={isSaving}
                className="w-full bg-zinc-900 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 disabled:opacity-50 shadow-xl shadow-zinc-900/10"
              >
                {isSaving ? 'Guardando...' : 'Finalizar'} <Sparkles size={20} />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
