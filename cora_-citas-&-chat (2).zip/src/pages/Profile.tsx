import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { motion, AnimatePresence, Reorder } from 'motion/react';
import { 
  Settings, LogOut, Camera, Shield, HelpCircle, 
  ChevronRight, Pencil, Sparkles, X, Plus, Trash2, 
  ChevronLeft, Save, Loader2, GripVertical, Lock, Unlock, Key,
  ShieldCheck, LayoutGrid, Play, RefreshCw, UserSquare, Eye, Menu, Share2, Heart
} from 'lucide-react';
import { doc, updateDoc, serverTimestamp, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import ProfileAgent from '../components/ProfileAgent';

export default function Profile() {
  const { user, profile, logout, refreshProfile } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [zoomedPhoto, setZoomedPhoto] = useState<string | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showLikeAnimation, setShowLikeAnimation] = useState(false);
  const [likedPhotos, setLikedPhotos] = useState<Set<string>>(new Set());
  const [likeAnimationTarget, setLikeAnimationTarget] = useState<string | null>(null);
  
  const toggleLikePhoto = (photoUrl: string) => {
    setLikedPhotos(prev => {
      const next = new Set(prev);
      if (next.has(photoUrl)) next.delete(photoUrl);
      else {
        next.add(photoUrl);
        setLikeAnimationTarget(photoUrl);
        setTimeout(() => setLikeAnimationTarget(null), 800);
      }
      return next;
    });
  };
  const [editForm, setEditForm] = useState({
    displayName: profile?.displayName || '',
    age: profile?.age || 18,
    bio: profile?.bio || '',
    gender: profile?.gender || 'other',
    interestedIn: profile?.interestedIn || 'both',
    photos: profile?.photos || [],
    privatePhotos: (profile as any)?.privatePhotos || [],
    location: profile?.location || '',
    vaultPin: (profile as any)?.vaultPin || '',
    vaultBackground: (profile as any)?.vaultBackground || ''
  });

  const [isUnlocked, setIsUnlocked] = useState(false);
  const [pinBuffer, setPinBuffer] = useState('');
  const [privatePhotosStaged, setPrivatePhotosStaged] = useState<string[]>([]);
  const [isSavingPrivate, setIsSavingPrivate] = useState(false);
  const vaultBgInputRef = useRef<HTMLInputElement>(null);

  // Initialize staged photos when unlocked
  useEffect(() => {
    if (isUnlocked && profile) {
      setPrivatePhotosStaged((profile as any).privatePhotos || []);
    }
  }, [isUnlocked, profile]);

  // Sync editForm with profile when profile updates (important since gallery is now on main page)
  useEffect(() => {
    if (profile) {
      setEditForm(prev => ({
        ...prev,
        photos: profile.photos || [],
        privatePhotos: (profile as any).privatePhotos || [],
        vaultPin: (profile as any).vaultPin || prev.vaultPin,
        vaultBackground: (profile as any).vaultBackground || prev.vaultBackground,
        displayName: prev.displayName || profile.displayName,
        age: prev.age || profile.age,
        bio: prev.bio || profile.bio,
        gender: prev.gender || profile.gender,
        interestedIn: prev.interestedIn || profile.interestedIn,
        location: prev.location || profile.location
      }));
    }
  }, [profile]);

  const privateFileInputRef = useRef<HTMLInputElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mainFileInputRef = useRef<HTMLInputElement>(null);

  if (!profile) return null;

  const compressImage = (base64Str: string, maxWidth = 800, quality = 0.7): Promise<string> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.src = base64Str;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > maxWidth) {
          height = (height * maxWidth) / width;
          width = maxWidth;
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
    });
  };

  const handleMainPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && user) {
      if (file.size > 2 * 1024 * 1024) {
        alert('La imagen es demasiado grande. Por favor, elige una menor a 2MB.');
        return;
      }
      setIsSaving(true);
      const reader = new FileReader();
      reader.onloadend = async () => {
        const rawBase64 = reader.result as string;
        const base64String = await compressImage(rawBase64);
        try {
          // Prepend to the photos array to make it the main one
          const newPhotos = [base64String, ...(profile.photos || [])].slice(0, 6);
          await updateDoc(doc(db, 'users', user.uid), {
            photos: newPhotos,
            updatedAt: serverTimestamp()
          });
          await refreshProfile();
        } catch (error: any) {
          console.error('Error uploading main photo:', error);
          if (error.message?.includes('exceeds the maximum allowed size')) {
            alert('Has alcanzado el límite de almacenamiento (1MB). Intenta borrar algunas fotos antes de añadir nuevas.');
          }
        } finally {
          setIsSaving(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUpdateProfile = async () => {
    if (!user) return;
    setIsSaving(true);
    try {
      // Calculate approximate size
      const dataString = JSON.stringify(editForm);
      if (dataString.length > 900000) { // Safety margin for 1MB
        alert('Tu perfil es demasiado grande (cerca de 1MB). Intenta reducir el tamaño de las fotos o eliminar algunas.');
        setIsSaving(false);
        return;
      }

      await updateDoc(doc(db, 'users', user.uid), {
        ...editForm,
        updatedAt: serverTimestamp()
      });
      await refreshProfile();
      setIsEditing(false);
      setPinBuffer(''); // Clear buffer on save
    } catch (error: any) {
      console.error('Error updating profile:', error);
      if (error.message?.includes('exceeds the maximum allowed size')) {
        alert('No se pudo guardar: el perfil excede el límite de 1MB de base de datos. Borra algunas fotos e inténtalo de nuevo.');
      }
    } finally {
      setIsSaving(false);
    }
  };

  const handleVaultBackgroundUpload = async (e: React.ChangeEvent<HTMLInputElement>, saveImmediately: boolean = false) => {
    const file = e.target.files?.[0];
    if (file && user) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const rawBase64 = reader.result as string;
        const compressed = await compressImage(rawBase64, 1200, 0.6); // Slightly better for BG
        
        if (saveImmediately) {
          setIsSavingPrivate(true);
          try {
            await updateDoc(doc(db, 'users', user.uid), {
              vaultBackground: compressed,
              updatedAt: serverTimestamp()
            });
            await refreshProfile();
          } catch (error) {
            console.error('Error auto-saving vault background:', error);
          } finally {
            setIsSavingPrivate(false);
          }
        } else {
          setEditForm(prev => ({ ...prev, vaultBackground: compressed }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, isPrivate: boolean = false) => {
    const file = e.target.files?.[0];
    if (file && user) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const rawBase64 = reader.result as string;
        const base64String = await compressImage(rawBase64);
        
        if (isPrivate) {
          setPrivatePhotosStaged(prev => [...prev, base64String]);
        } else {
          try {
            const newPhotos = [...(profile.photos || []), base64String];
            await updateDoc(doc(db, 'users', user.uid), {
              photos: newPhotos,
              updatedAt: serverTimestamp()
            });
            await refreshProfile();
          } catch (error: any) {
            console.error('Error uploading photo:', error);
            if (error.message?.includes('exceeds the maximum allowed size')) {
              alert('Error: Límite de 1MB excedido. No se pueden añadir más fotos sin borrar otras.');
            }
          }
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const removePhoto = async (index: number, isPrivate: boolean = false) => {
    if (!user) return;
    if (isPrivate) {
      setPrivatePhotosStaged(prev => prev.filter((_, i) => i !== index));
    } else {
      const newPhotos = (profile.photos || []).filter((_: any, i: number) => i !== index);
      await updateDoc(doc(db, 'users', user.uid), {
        photos: newPhotos,
        updatedAt: serverTimestamp()
      });
      await refreshProfile();
    }
  };

  const handleSavePrivatePhotos = async (photosToSave?: string[]) => {
    if (!user) return;
    const dataToSave = photosToSave || privatePhotosStaged;
    setIsSavingPrivate(true);
    try {
      // Size check
      const stagedSize = JSON.stringify(dataToSave).length;
      if (stagedSize > 800000) {
        alert('Demasiado contenido para guardar (límite 1MB). Por favor, elimina algunas fotos privadas.');
        setIsSavingPrivate(false);
        return;
      }

      await updateDoc(doc(db, 'users', user.uid), {
        privatePhotos: dataToSave,
        updatedAt: serverTimestamp()
      });
      await refreshProfile();
    } catch (error: any) {
      console.error('Error saving private photos:', error);
      if (error.message?.includes('exceeds the maximum allowed size')) {
        alert('Error: No se pueden guardar tantas fotos privadas en el mismo perfil (Límite 1MB).');
      }
    } finally {
      setIsSavingPrivate(false);
    }
  };

  // Debounced auto-save for private photos
  useEffect(() => {
    if (!isUnlocked || !profile) return;
    
    const currentPrivate = (profile as any).privatePhotos || [];
    const isDifferent = JSON.stringify(privatePhotosStaged) !== JSON.stringify(currentPrivate);
    
    if (isDifferent && !isSavingPrivate) {
      const timer = setTimeout(() => {
        handleSavePrivatePhotos();
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [privatePhotosStaged, isUnlocked, profile]);

  const handleReorderPhotos = async (newPhotos: string[]) => {
    if (!user) return;
    try {
      await updateDoc(doc(db, 'users', user.uid), {
        photos: newPhotos,
        updatedAt: serverTimestamp()
      });
      await refreshProfile();
    } catch (error) {
      console.error('Error reordering photos:', error);
    }
  };

  const [activeTab, setActiveTab] = useState<'posts' | 'private'>('posts');

  const photos = profile.photos || [];
  const privatePhotos = (profile as any).privatePhotos || [];

  const handlePinInput = (digit: string) => {
    const newBuffer = pinBuffer + digit;
    if (newBuffer.length <= (editForm.vaultPin?.length || 4)) {
      setPinBuffer(newBuffer);
      if (newBuffer === editForm.vaultPin) {
        setIsUnlocked(true);
        setPinBuffer('');
      } else if (newBuffer.length === (editForm.vaultPin?.length || 4)) {
        setTimeout(() => setPinBuffer(''), 500);
      }
    }
  };

  return (
    <div className="max-w-xl mx-auto pb-32 bg-white min-h-screen">
      {/* Refined Header */}
      <div className="px-6 pt-8 pb-4">
        <div className="flex justify-between items-start mb-6">
          <div className="flex items-center gap-4">
            <div className="relative group">
              <div className="w-20 h-20 rounded-full border-2 border-zinc-200 p-1">
                <img 
                  src={photos[0] || `https://api.dicebear.com/7.x/avataaars/svg?seed=${user?.uid}`} 
                  className="w-full h-full rounded-full object-cover"
                  alt="Avatar"
                />
              </div>
              <button 
                onClick={() => mainFileInputRef.current?.click()}
                className="absolute bottom-0 right-0 p-1.5 bg-brand text-white rounded-full shadow-lg border-2 border-white scale-90"
              >
                <Plus size={12} strokeWidth={3} />
              </button>
            </div>
            <div>
              <h2 className="text-xl font-bold flex items-center gap-1.5">
                {profile.displayName}
                <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-[8px] text-white font-black">✓</span>
                </div>
                <motion.button 
                  whileTap={{ scale: 0.8 }}
                  onClick={() => {
                    setShowLikeAnimation(true);
                    setTimeout(() => setShowLikeAnimation(false), 1000);
                  }}
                  className="ml-1 p-1 text-rose-500 active:text-rose-600 transition-colors"
                >
                  <Heart size={18} fill={showLikeAnimation ? "currentColor" : "none"} strokeWidth={2.5} />
                </motion.button>
              </h2>
              <p className="text-xs text-zinc-500 font-medium tracking-tight">{profile.location || 'Ubicación no establecida'}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <button 
              onClick={() => {
                setEditForm({
                  displayName: profile.displayName,
                  age: profile.age,
                  bio: profile.bio || '',
                  gender: profile.gender || 'other',
                  interestedIn: profile.interestedIn || 'both',
                  photos: profile.photos || [],
                  privatePhotos: (profile as any).privatePhotos || [],
                  location: profile.location || '',
                  vaultPin: (profile as any).vaultPin || '',
                  vaultBackground: (profile as any).vaultBackground || ''
                });
                setIsEditing(true);
              }}
              title="Editar detalles"
              className="p-3.5 bg-zinc-900 text-white rounded-2xl shadow-xl shadow-zinc-200 transition-all hover:bg-black hover:scale-105 active:scale-95 group flex items-center justify-center"
            >
              <Pencil size={18} strokeWidth={2.5} className="group-hover:rotate-12 transition-transform" />
            </button>
            <button 
              onClick={() => setShowSettings(true)}
              className="p-3 bg-white border border-zinc-200 rounded-2xl shadow-sm text-zinc-900 transition-all hover:border-zinc-900 active:scale-95 group"
            >
              <Settings size={20} />
            </button>
          </div>
        </div>

        <div className="mb-6 space-y-1">
          <p className="text-sm font-semibold">{profile.age} años</p>
          <p className="text-sm text-zinc-600 leading-snug">{profile.bio || 'Sin biografía aún...'}</p>
        </div>

        {/* Stats Grid */}
        <div className="flex gap-8 border-t border-zinc-50 pt-4">
          <div className="text-center">
            <p className="font-black text-sm">{photos.length}</p>
            <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">Posts</p>
          </div>
          <div className="text-center">
            <p className="font-black text-sm">1.2k</p>
            <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">Fans</p>
          </div>
          <div className="text-center">
            <p className="font-black text-sm">348</p>
            <p className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider">Fotos</p>
          </div>
        </div>
      </div>

      {/* Social Tab Bar */}
      <div className="flex border-t border-zinc-100 sticky top-0 bg-white/95 backdrop-blur-lg z-30">
        {[
          { id: 'posts', icon: LayoutGrid },
          { id: 'private', icon: Lock },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex-1 py-3 flex justify-center items-center transition-colors relative ${
              activeTab === tab.id ? 'text-zinc-950' : 'text-zinc-300'
            }`}
          >
            <tab.icon 
              size={24} 
              strokeWidth={activeTab === tab.id ? 2.5 : 1.5} 
            />
            {activeTab === tab.id && (
              <motion.div 
                layoutId="activeTab"
                className="absolute bottom-0 inset-x-0 h-0.5 bg-zinc-950"
              />
            )}
          </button>
        ))}
      </div>

      {/* Content Grid */}
      <div className="bg-zinc-100 min-h-[40vh]">
        <AnimatePresence>
          {showLikeAnimation && (
            <motion.div 
              initial={{ scale: 0, opacity: 0 }}
              animate={{ 
                scale: [0, 1.8, 1.2], 
                opacity: [0, 1, 0],
                rotate: [0, -10, 10, 0]
              }}
              transition={{ duration: 0.8, ease: "easeOut" }}
              className="fixed inset-0 pointer-events-none flex items-center justify-center z-[200]"
            >
              <Heart size={180} fill="#f43f5e" className="text-rose-500 drop-shadow-[0_0_30px_rgba(244,63,94,0.4)]" />
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence mode="wait">
          {activeTab === 'posts' ? (
            <Reorder.Group 
              axis="y" 
              values={photos} 
              onReorder={handleReorderPhotos}
              className="grid grid-cols-3 gap-[2px]"
            >
              {photos.map((photo, i) => (
                <Reorder.Item
                  key={photo}
                  value={photo}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  whileHover={{ 
                    scale: 1.02, 
                    boxShadow: "0 10px 25px -5px rgba(99, 102, 241, 0.3)",
                    zIndex: 10,
                    transition: { duration: 0.2 }
                  }}
                  transition={{ 
                    duration: 0.5, 
                    delay: (i % 3) * 0.05,
                    ease: [0.21, 0.47, 0.32, 0.98] 
                  }}
                  className="relative aspect-square group cursor-grab active:cursor-grabbing bg-zinc-200 overflow-hidden rounded-sm"
                  onClick={(e) => {
                    // If it's a double click/tap, like it
                    if (e.detail === 2) {
                      toggleLikePhoto(photo);
                    } else {
                      setZoomedPhoto(photo);
                    }
                  }}
                >
                  <img 
                    src={photo} 
                    className="w-full h-full object-cover pointer-events-none" 
                    alt={`Post ${i}`} 
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors pointer-events-none" />
                  
                  {/* Photo Actions Overlay */}
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                    <motion.button
                      whileTap={{ scale: 0.8 }}
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleLikePhoto(photo);
                      }}
                      className={`w-10 h-10 rounded-full backdrop-blur-md flex items-center justify-center transition-all ${
                        likedPhotos.has(photo) 
                          ? 'bg-rose-500 text-white' 
                          : 'bg-white/20 text-white border border-white/30'
                      }`}
                    >
                      <Heart size={20} fill={likedPhotos.has(photo) ? "currentColor" : "none"} strokeWidth={2.5} />
                    </motion.button>
                  </div>

                  {/* Individual Like Animation */}
                  <AnimatePresence>
                    {likeAnimationTarget === photo && (
                      <motion.div
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{ scale: [0, 1.5, 1], opacity: [0, 1, 0] }}
                        exit={{ scale: 0, opacity: 0 }}
                        className="absolute inset-0 flex items-center justify-center pointer-events-none z-20"
                      >
                        <Heart size={48} fill="white" className="text-white drop-shadow-2xl" />
                      </motion.div>
                    )}
                  </AnimatePresence>
                  
                  {/* Reorder Handle Visual */}
                  <div className="absolute top-2 left-2 p-1 bg-white/20 backdrop-blur-md rounded-md opacity-0 group-hover:opacity-100 transition-opacity">
                    <GripVertical size={12} className="text-white" />
                  </div>
                </Reorder.Item>
              ))}
              {photos.length < 12 && (
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="aspect-square bg-white flex items-center justify-center text-zinc-300 hover:text-brand transition-colors m-[10px] rounded-xl border-2 border-dashed border-zinc-100"
                >
                  <Plus size={32} strokeWidth={1} />
                </button>
              )}
            </Reorder.Group>
          ) : (
            <motion.div 
              key="private"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="min-h-[40vh]"
            >
              {!editForm.vaultPin ? (
                <div className="flex flex-col items-center justify-center p-12 text-center space-y-6 min-h-[50vh] bg-white">
                  <div className="w-24 h-24 bg-zinc-100 rounded-[2.5rem] flex items-center justify-center text-zinc-400 rotate-12 transition-transform hover:rotate-0">
                    <ShieldCheck size={48} strokeWidth={1.5} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-2xl font-black italic tracking-tighter uppercase">Caja Fuerte</h3>
                    <p className="text-zinc-500 text-sm max-w-[240px] mx-auto font-medium">
                      Protege tus fotos más íntimas con un código PIN de seguridad.
                    </p>
                  </div>
                  <button 
                    onClick={() => setIsEditing(true)}
                    className="px-8 py-3 bg-zinc-900 text-white rounded-2xl text-sm font-bold shadow-xl shadow-black/10 active:scale-95 transition-all"
                  >
                    Configurar PIN ahora
                  </button>
                </div>
              ) : !isUnlocked ? (
                <div className="relative h-full min-h-[60vh] flex flex-col bg-zinc-950 overflow-hidden">
                  {/* Custom Background or Default */}
                  <div className="absolute inset-0 z-0">
                    {editForm.vaultBackground ? (
                      <img 
                        src={editForm.vaultBackground} 
                        className="w-full h-full object-cover blur-md brightness-50 opacity-40"
                        alt="Vault BG"
                      />
                    ) : (
                      <div className="w-full h-full bg-zinc-900" />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-b from-black/0 via-black/20 to-zinc-950" />
                  </div>

                  <div className="relative z-10 p-6 flex flex-col h-full">
                    {/* Ghost Grid - The "Locked" Thumbnails */}
                    <div className="grid grid-cols-3 gap-[4px] mb-8 opacity-40">
                      {[...Array(6)].map((_, i) => (
                        <motion.div
                          key={i}
                          whileHover={{ 
                            scale: 1.05, 
                            backgroundColor: 'rgba(255, 255, 255, 0.15)',
                            transition: { duration: 0.2 }
                          }}
                          whileTap={{ scale: 0.95 }}
                          className="aspect-square bg-white/5 backdrop-blur-md rounded-2xl border border-white/10 flex items-center justify-center text-white/20"
                        >
                          <Lock size={20} strokeWidth={1} />
                        </motion.div>
                      ))}
                    </div>

                    <div className="text-center space-y-6 flex-grow flex flex-col justify-center">
                      <motion.div 
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        className="space-y-2"
                      >
                        <h3 className="text-xl font-black italic tracking-tight text-white uppercase select-none">Caja Fuerte</h3>
                        <div className="flex justify-center gap-3">
                          {[...Array(editForm.vaultPin.length)].map((_, i) => (
                            <motion.div 
                              key={i} 
                              animate={pinBuffer.length === i ? { scale: [1, 1.2, 1] } : {}}
                              className={`w-3 h-3 rounded-full border-2 transition-all duration-300 ${
                                pinBuffer.length > i 
                                  ? 'bg-white border-white shadow-[0_0_15px_rgba(255,255,255,0.6)]' 
                                  : 'bg-transparent border-white/20'
                              }`}
                            />
                          ))}
                        </div>
                      </motion.div>

                      {/* Keypad */}
                      <div className="grid grid-cols-3 gap-3 max-w-[260px] mx-auto">
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, '', 0, 'delete'].map((btn, i) => (
                          <motion.button
                            key={i}
                            whileHover={btn !== '' ? { 
                              backgroundColor: 'rgba(255, 255, 255, 0.2)',
                              scale: 1.05
                            } : {}}
                            whileTap={btn !== '' ? { scale: 0.9 } : {}}
                            onClick={() => {
                              if (btn === 'delete') setPinBuffer(prev => prev.slice(0, -1));
                              else if (btn !== '') handlePinInput(btn.toString());
                            }}
                            className={`w-14 h-14 rounded-full flex items-center justify-center text-lg font-black transition-all ${
                              btn === '' ? 'invisible' : 'bg-white/10 backdrop-blur-xl text-white border border-white/5 shadow-2xl'
                            }`}
                          >
                            {btn === 'delete' ? <ChevronLeft size={20} /> : btn}
                          </motion.button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col">
                  {/* Private Gallery Header/Actions */}
                  <div className="px-4 py-3 bg-white border-b border-zinc-100 flex justify-between items-center sticky top-[52px] z-20">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 bg-indigo-50 text-indigo-500 rounded-lg flex items-center justify-center">
                        <Shield size={16} />
                      </div>
                      <span className="text-xs font-black uppercase tracking-tight">Fotos Privadas</span>
                    </div>
                    
                    <div className="flex gap-2 items-center">
                      <button 
                        onClick={() => vaultBgInputRef.current?.click()}
                        className="p-1.5 bg-zinc-100 text-zinc-500 rounded-lg hover:bg-zinc-200 transition-colors"
                        title="Cambiar fondo de caja fuerte"
                      >
                        <Camera size={18} />
                      </button>
                      {isSavingPrivate && (
                        <motion.div 
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          className="flex items-center gap-1.5 px-2 py-1 bg-indigo-50 text-indigo-600 rounded-lg"
                        >
                          <Loader2 size={10} className="animate-spin" />
                          <span className="text-[10px] font-black uppercase tracking-tight">Guardando</span>
                        </motion.div>
                      )}
                      {JSON.stringify(privatePhotosStaged) !== JSON.stringify((profile as any).privatePhotos || []) && (
                        <motion.button 
                          initial={{ scale: 0.8, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          onClick={() => handleSavePrivatePhotos()}
                          disabled={isSavingPrivate}
                          className="px-4 py-1.5 bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-lg shadow-indigo-200 active:scale-95 disabled:opacity-50 transition-all"
                        >
                          <Save size={14} />
                          Finalizar
                        </motion.button>
                      )}
                      <button 
                        onClick={() => setIsUnlocked(false)}
                        className="p-1.5 bg-zinc-100 text-zinc-500 rounded-lg hover:bg-zinc-200 transition-colors"
                      >
                        <Unlock size={18} />
                      </button>
                    </div>
                  </div>

                  <Reorder.Group 
                    axis="y" 
                    values={privatePhotosStaged} 
                    onReorder={setPrivatePhotosStaged}
                    className="grid grid-cols-3 gap-[2px]"
                  >
                    {privatePhotosStaged.map((photo: any, i: number) => (
                      <Reorder.Item 
                        key={photo} 
                        value={photo}
                        initial={{ opacity: 0, scale: 0.95 }}
                        animate={{ opacity: 1, scale: 1 }}
                        whileHover={{ 
                          scale: 1.02, 
                          boxShadow: "0 10px 25px -5px rgba(99, 102, 241, 0.3)",
                          zIndex: 10,
                          transition: { duration: 0.2 }
                        }}
                        className="relative aspect-square group bg-zinc-200 cursor-grab active:cursor-grabbing overflow-hidden rounded-sm" 
                        onClick={(e) => {
                          if (e.detail === 2) {
                            toggleLikePhoto(photo);
                          } else {
                            setZoomedPhoto(photo);
                          }
                        }}
                      >
                        <img src={photo} className="w-full h-full object-cover pointer-events-none" alt="" />
                        
                        {/* Private Photo Actions */}
                        <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                          <motion.button
                            whileTap={{ scale: 0.8 }}
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleLikePhoto(photo);
                            }}
                            className={`w-8 h-8 rounded-full backdrop-blur-md flex items-center justify-center transition-all ${
                              likedPhotos.has(photo) 
                                ? 'bg-rose-500 text-white' 
                                : 'bg-white/20 text-white border border-white/30'
                            }`}
                          >
                            <Heart size={16} fill={likedPhotos.has(photo) ? "currentColor" : "none"} strokeWidth={2.5} />
                          </motion.button>
                        </div>

                        {/* Individual Like Animation */}
                        <AnimatePresence>
                          {likeAnimationTarget === photo && (
                            <motion.div
                              initial={{ scale: 0, opacity: 0 }}
                              animate={{ scale: [0, 1.5, 1], opacity: [0, 1, 0] }}
                              exit={{ scale: 0, opacity: 0 }}
                              className="absolute inset-0 flex items-center justify-center pointer-events-none z-20"
                            >
                              <Heart size={40} fill="white" className="text-white drop-shadow-2xl" />
                            </motion.div>
                          )}
                        </AnimatePresence>

                        <button 
                          onClick={(e) => {
                            e.stopPropagation();
                            removePhoto(i, true);
                          }}
                          className="absolute top-2 right-2 p-1.5 bg-black/50 text-white rounded-lg backdrop-blur-md opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 size={12} />
                        </button>

                        <div className="absolute top-2 left-2 p-1 bg-white/20 backdrop-blur-md rounded-md opacity-0 group-hover:opacity-100 transition-opacity">
                          <GripVertical size={12} className="text-white" />
                        </div>
                      </Reorder.Item>
                    ))}
                    <button 
                      onClick={() => privateFileInputRef.current?.click()}
                      className="aspect-square bg-white flex items-center justify-center text-zinc-300 hover:text-indigo-500 transition-colors m-[10px] rounded-xl border-2 border-dashed border-zinc-100"
                    >
                      <Plus size={32} strokeWidth={1} />
                    </button>
                  </Reorder.Group>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer */}
      <div className="mt-12 text-center opacity-30 filter grayscale mb-8">
        <div className="flex items-center justify-center gap-2 mb-2">
          <div className="w-6 h-6 bg-brand rounded-lg flex items-center justify-center text-white">
            <Sparkles fill="currentColor" size={12} />
          </div>
          <span className="text-sm font-display font-bold">Cora</span>
        </div>
        <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">Versión 1.0.4 - 2026</p>
      </div>

      <ProfileAgent 
        profile={profile} 
        onUpdateBio={(newBio) => {
          setEditForm(prev => ({ ...prev, bio: newBio }));
          setIsEditing(true);
        }} 
      />

      {/* Hidden File Inputs */}
      <input 
        type="file" 
        ref={fileInputRef} 
        className="hidden" 
        accept="image/*" 
        onChange={(e) => handleFileUpload(e, false)} 
      />
      <input 
        type="file" 
        ref={privateFileInputRef} 
        className="hidden" 
        accept="image/*" 
        onChange={(e) => handleFileUpload(e, true)} 
      />
      <input 
        type="file" 
        ref={mainFileInputRef} 
        className="hidden" 
        accept="image/*" 
        onChange={handleMainPhotoUpload} 
      />
      <input 
        type="file" 
        ref={vaultBgInputRef} 
        className="hidden" 
        accept="image/*" 
        onChange={(e) => handleVaultBackgroundUpload(e, isUnlocked)} 
      />

      {/* Settings Modal */}
      <AnimatePresence>
        {showSettings && (
          <div className="fixed inset-0 z-[110] flex items-end md:items-center md:justify-center p-0 md:p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSettings(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-md"
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              className="relative w-full max-w-md bg-white rounded-t-[2.5rem] md:rounded-[2.5rem] p-8 space-y-6 overflow-hidden"
            >
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-black italic tracking-tight">Ajustes</h2>
                <button onClick={() => setShowSettings(false)} className="p-2 bg-zinc-100 rounded-full">
                  <X size={20} />
                </button>
              </div>

              <div className="space-y-4">
                <button 
                  onClick={() => {
                    setIsEditing(true);
                    setShowSettings(false);
                  }}
                  className="w-full flex items-center gap-4 p-4 hover:bg-zinc-50 rounded-2xl transition-colors"
                >
                  <div className="w-10 h-10 bg-indigo-50 text-indigo-500 rounded-xl flex items-center justify-center">
                    <Pencil size={20} />
                  </div>
                  <span className="font-bold">Editar Perfil</span>
                </button>

                <button className="w-full flex items-center gap-4 p-4 hover:bg-zinc-50 rounded-2xl transition-colors">
                  <div className="w-10 h-10 bg-emerald-50 text-emerald-500 rounded-xl flex items-center justify-center">
                    <Shield size={20} />
                  </div>
                  <span className="font-bold">Privacidad</span>
                </button>

                <button 
                  onClick={() => {
                    const url = window.location.href;
                    if (navigator.share) {
                      navigator.share({
                        title: `Perfil de ${profile.displayName} en Cora`,
                        url: url
                      }).catch(console.error);
                    } else {
                      navigator.clipboard.writeText(url);
                      alert('¡Enlace copiado al portapapeles!');
                    }
                  }}
                  className="w-full flex items-center gap-4 p-4 hover:bg-zinc-50 rounded-2xl transition-colors"
                >
                  <div className="w-10 h-10 bg-blue-50 text-blue-500 rounded-xl flex items-center justify-center">
                    <Share2 size={20} />
                  </div>
                  <span className="font-bold">Compartir Perfil</span>
                </button>

                <div className="h-[1px] bg-zinc-100 my-2" />

                <button 
                  onClick={() => {
                    setShowSettings(false);
                    logout();
                  }}
                  className="w-full flex items-center gap-4 p-4 text-rose-500 hover:bg-rose-50 rounded-2xl transition-colors"
                >
                  <div className="w-10 h-10 bg-rose-50 rounded-xl flex items-center justify-center">
                    <LogOut size={20} />
                  </div>
                  <span className="font-bold">Cerrar Sesión</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Modal */}
      <AnimatePresence>
        {isEditing && (
          <div className="fixed inset-0 z-[100] flex flex-col md:items-center md:justify-center">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsEditing(false)}
              className="absolute inset-0 bg-zinc-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="relative w-full max-w-xl h-full md:h-[90vh] bg-white md:rounded-3xl flex flex-col overflow-hidden"
            >
              {/* Modal Header */}
              <div className="px-6 py-4 border-b border-zinc-100 flex items-center justify-between sticky top-0 bg-white z-10">
                <button onClick={() => setIsEditing(false)} className="p-2 -ml-2 text-zinc-400">
                  <X size={24} />
                </button>
                <h2 className="font-bold text-xl">Editar Perfil</h2>
                <button 
                  onClick={handleUpdateProfile}
                  disabled={isSaving}
                  className="px-4 py-2 bg-brand text-white rounded-xl font-bold text-sm disabled:opacity-70 flex items-center gap-2 transition-all active:scale-95"
                >
                  {isSaving ? (
                    <><Loader2 size={16} className="animate-spin" /> Guardando...</>
                  ) : (
                    <><Save size={16}/> Guardar</>
                  )}
                </button>
              </div>

              {/* Scrollable Form */}
              <div className="flex-1 overflow-y-auto p-6 space-y-8 pb-32">
                {/* Name & Age */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">Nombre</label>
                    <input 
                      type="text"
                      className="w-full p-4 bg-zinc-50 border border-zinc-100 rounded-2xl outline-none focus:border-brand"
                      value={editForm.displayName}
                      onChange={(e) => setEditForm({...editForm, displayName: e.target.value})}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">Edad</label>
                    <input 
                      type="number"
                      className="w-full p-4 bg-zinc-50 border border-zinc-100 rounded-2xl outline-none focus:border-brand"
                      value={editForm.age}
                      onChange={(e) => setEditForm({...editForm, age: parseInt(e.target.value) || 18})}
                    />
                  </div>
                </div>

                {/* Location */}
                <div className="space-y-1">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">Ubicación</label>
                  <input 
                    type="text"
                    className="w-full p-4 bg-zinc-50 border border-zinc-100 rounded-2xl outline-none focus:border-brand"
                    value={editForm.location}
                    onChange={(e) => setEditForm({...editForm, location: e.target.value})}
                    placeholder="Eje: Madrid, ES"
                  />
                </div>

                {/* Bio */}
                <div className="space-y-1">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">Sobre mí</label>
                  <textarea 
                    className="w-full p-4 bg-zinc-50 border border-zinc-100 rounded-2xl outline-none focus:border-brand h-32 resize-none"
                    value={editForm.bio}
                    onChange={(e) => setEditForm({...editForm, bio: e.target.value})}
                    placeholder="Cuéntales algo interesante..."
                  />
                </div>

                {/* Gender Options */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-wider text-zinc-400 block pb-1">Identidad</label>
                    <div className="grid grid-cols-3 gap-2">
                      {['male', 'female', 'other'].map((g) => (
                        <button
                          key={g}
                          onClick={() => setEditForm({ ...editForm, gender: g as any })}
                          className={`py-3 rounded-xl border text-sm font-medium transition-all ${
                            editForm.gender === g ? 'bg-brand text-white border-brand' : 'bg-zinc-50 text-zinc-600 border-zinc-100'
                          }`}
                        >
                          {g === 'male' ? 'Hombre' : g === 'female' ? 'Mujer' : 'Otro'}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Vault Background Settings */}
                <div className="space-y-4">
                  <label className="text-xs font-bold uppercase tracking-wider text-zinc-400 block">Personalización de Caja Fuerte</label>
                  <div className="relative aspect-video rounded-2xl bg-zinc-100 border border-zinc-200 overflow-hidden group">
                    {editForm.vaultBackground ? (
                      <img src={editForm.vaultBackground} className="w-full h-full object-cover" alt="Vault Preview" />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-zinc-400 gap-2">
                        <Camera size={24} />
                        <span className="text-xs font-medium">Sin imagen de fondo</span>
                      </div>
                    )}
                    <button 
                      onClick={() => vaultBgInputRef.current?.click()}
                      className="absolute inset-0 bg-black/40 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Pencil size={20} />
                    </button>
                    {editForm.vaultBackground && (
                      <button 
                        onClick={() => setEditForm(prev => ({ ...prev, vaultBackground: '' }))}
                        className="absolute top-2 right-2 p-1.5 bg-rose-500 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 size={14} />
                      </button>
                    )}
                  </div>
                  
                  <div className="space-y-1">
                    <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">PIN de Caja Fuerte</label>
                    <input 
                      type="text"
                      maxLength={4}
                      className="w-full p-4 bg-zinc-50 border border-zinc-100 rounded-2xl outline-none focus:border-brand font-mono tracking-widest text-center text-lg"
                      value={editForm.vaultPin}
                      onChange={(e) => setEditForm({...editForm, vaultPin: e.target.value})}
                      placeholder="Eje: 1234"
                    />
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <AnimatePresence>
        {zoomedPhoto && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setZoomedPhoto(null)}
            className="fixed inset-0 z-[200] bg-black/90 flex flex-col items-center justify-center p-4 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="relative w-full max-w-2xl h-[70vh] md:h-[80vh] overflow-hidden rounded-[2.5rem] bg-zinc-900 border border-white/10 shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <img 
                src={zoomedPhoto} 
                alt="Zoomed" 
                className="w-full h-full object-contain"
              />
              <div className="absolute top-0 inset-x-0 p-6 bg-gradient-to-b from-black/50 to-transparent flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-brand/20 backdrop-blur-md flex items-center justify-center text-brand">
                    <Sparkles size={16} />
                  </div>
                  <span className="text-white font-bold text-sm">Vista Detallada</span>
                </div>
                <button 
                  onClick={() => setZoomedPhoto(null)}
                  className="p-3 bg-white/10 backdrop-blur-md rounded-full text-white shadow-lg active:scale-90 transition-transform hover:bg-white/20"
                >
                  <X size={20} />
                </button>
              </div>
            </motion.div>
            <motion.p 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-white/40 text-[10px] mt-8 font-black uppercase tracking-[0.2em] bg-white/5 px-4 py-2 rounded-full border border-white/10 backdrop-blur-sm"
            >
              Pulsa fuera para cerrar
            </motion.p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
