import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { collection, query, where, onSnapshot, orderBy, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, Heart, ChevronRight, Sparkles, X } from 'lucide-react';

interface Match {
  id: string;
  uids: string[];
  lastMessage: string;
  lastMessageAt: any;
  otherUser?: any;
}

export default function Matches() {
  const { user } = useAuth();
  const [matches, setMatches] = useState<Match[]>([]);
  const [filteredMatches, setFilteredMatches] = useState<Match[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'date' | 'active'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [newMatchNotification, setNewMatchNotification] = useState<any>(null);
  const isFirstLoad = useRef(true);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'matches'),
      where('uids', 'array-contains', user.uid),
      orderBy('lastMessageAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, async (snapshot) => {
      const matchData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Match));
      
      const enrichedMatches = await Promise.all(matchData.map(async (m) => {
        const otherUid = m.uids.find(id => id !== user.uid);
        if (!otherUid) return m;
        
        const userDocRef = collection(db, 'users');
        const userQuery = query(userDocRef, where('uid', '==', otherUid));
        const userSnapshot = await getDocs(userQuery);
        const otherUser = userSnapshot.docs[0]?.data();
        
        return { ...m, otherUser };
      }));

      setMatches(enrichedMatches);
      setLoading(false);
      isFirstLoad.current = false;
    });

    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    let result = [...matches];

    // Filter by Search Query
    if (searchQuery.trim()) {
      result = result.filter(m => 
        m.otherUser?.displayName?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Filter by Category
    if (filter === 'date') {
      // Sort by date (already handled by firestore query, but ensuring local consistency)
      result = result.sort((a, b) => {
        const bTime = b.lastMessageAt?.toMillis() || 0;
        const aTime = a.lastMessageAt?.toMillis() || 0;
        return bTime - aTime;
      });
    } else if (filter === 'active') {
      // Show users who have been active recently (mocking logic if field doesn't exist)
      result = result.filter(m => m.otherUser?.isOnline || m.otherUser?.photos?.length > 1);
    }

    setFilteredMatches(result);
  }, [filter, matches, searchQuery]);

  return (
    <div className="max-w-xl mx-auto px-6 py-8 relative pb-24">
      <AnimatePresence>
        {newMatchNotification && (
          <motion.div 
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.9 }}
            className="fixed top-6 left-6 right-6 z-[60] bg-brand text-white p-4 rounded-3xl shadow-2xl flex items-center gap-4 border border-white/20"
          >
            <div className="relative">
              <img 
                src={newMatchNotification.otherUser?.photos?.[0] || `https://api.dicebear.com/7.x/avataaars/svg?seed=${newMatchNotification.otherUser?.uid}`} 
                alt=""
                className="w-12 h-12 rounded-full object-cover border-2 border-white/30"
              />
              <div className="absolute -bottom-1 -right-1 bg-white p-1 rounded-full text-brand">
                <Heart fill="currentColor" size={12} />
              </div>
            </div>
            <div className="flex-1">
              <p className="text-sm font-bold">¡Nuevo Match con {newMatchNotification.otherUser?.displayName}!</p>
              <p className="text-xs opacity-80">¡Enhorabuena! Empezad a hablar ahora.</p>
            </div>
            <button onClick={() => setNewMatchNotification(null)} className="p-2 opacity-60">
              <X size={20} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <header className="mb-8 space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-4xl font-black italic tracking-tighter flex items-center gap-3">
            CHATS
            {matches.length > 0 && (
              <span className="text-xs bg-brand/10 text-brand px-3 py-1 rounded-full font-bold not-italic tracking-normal">
                {matches.length}
              </span>
            )}
          </h1>
        </div>

        {/* Search Bar */}
        <div className="relative">
          <input 
            type="text"
            placeholder="Buscar conversaciones..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-zinc-100 border-none rounded-2xl py-4 px-6 text-sm outline-none focus:ring-2 focus:ring-brand/20 transition-all placeholder:text-zinc-400 font-medium"
          />
          <div className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-300">
            <MessageCircle size={20} />
          </div>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2 hide-scrollbar">
          {[
            { id: 'all', label: 'Todos' },
            { id: 'date', label: 'Fecha' },
            { id: 'active', label: 'Activos' }
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id as any)}
              className={`px-6 py-2.5 rounded-2xl text-sm font-bold transition-all whitespace-nowrap border ${
                filter === f.id 
                  ? 'bg-zinc-900 text-white border-zinc-900 shadow-xl shadow-black/10' 
                  : 'bg-white text-zinc-500 border-zinc-100 hover:border-zinc-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </header>

      {loading ? (
        <div className="flex flex-col items-center justify-center pt-20 gap-4 opacity-40">
           <Heart fill="currentColor" className="text-brand animate-pulse" size={40} />
           <p className="text-sm font-medium">Buscando tus conexiones...</p>
        </div>
      ) : filteredMatches.length === 0 ? (
        <div className="flex flex-col items-center justify-center pt-20 text-center space-y-4">
          <div className="w-16 h-16 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-400">
            <MessageCircle size={32} />
          </div>
          <h2 className="text-lg font-bold">No se encontraron chats</h2>
          <p className="text-zinc-500 text-sm max-w-[200px]">
            {filter === 'all' 
              ? '¡Empieza a swipear para conseguir matches!' 
              : 'Prueba a cambiar el filtro para ver más mensajes.'}
          </p>
          {filter === 'all' && <Link to="/discover" className="text-brand font-bold text-sm">Ir a Descubrir</Link>}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredMatches.map((match) => (
            <Link 
              key={match.id} 
              to={`/matches/${match.id}`}
              className="block group"
            >
              <motion.div 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center gap-4 p-4 bg-white border border-zinc-100 rounded-2xl transition-all group-hover:border-zinc-200 group-hover:shadow-md"
              >
                <div className="relative">
                  <img 
                    src={match.otherUser?.photos?.[0] || `https://api.dicebear.com/7.x/avataaars/svg?seed=${match.otherUser?.uid}`} 
                    alt={match.otherUser?.displayName}
                    className="w-16 h-16 rounded-full object-cover bg-zinc-100"
                  />
                  <div className="absolute bottom-0 right-0 w-4 h-4 bg-green-500 border-2 border-white rounded-full" />
                </div>
                
                <div className="flex-1 min-w-0">
                  <h3 className="font-bold truncate">{match.otherUser?.displayName || 'Usuario'}</h3>
                  <p className="text-sm text-zinc-500 truncate">{match.lastMessage}</p>
                </div>

                <div className="text-zinc-300">
                  <ChevronRight size={20} />
                </div>
              </motion.div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
