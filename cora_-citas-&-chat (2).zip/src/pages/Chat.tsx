import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { db } from '../lib/firebase';
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, doc, getDoc, updateDoc, where, limit } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { Send, ChevronLeft, MoreVertical, Sparkles, Smile, Phone, Video, MessageCircle } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import CallOverlay from '../components/CallOverlay';

interface Message {
  id: string;
  senderUid: string;
  text: string;
  timestamp: any;
}

export default function Chat() {
  const { matchId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [otherUser, setOtherUser] = useState<any>(null);
  const [isAiSuggesting, setIsAiSuggesting] = useState(false);
  const [suggestedMessage, setSuggestedMessage] = useState('');
  const [bgColor, setBgColor] = useState('bg-white');
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [activeCall, setActiveCall] = useState<{ type: 'video' | 'voice', isIncoming: boolean, callId?: string } | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  const colors = [
    { id: 'bg-white', label: 'Blanco', class: 'bg-white border-zinc-200' },
    { id: 'bg-zinc-50', label: 'Gris', class: 'bg-zinc-50 border-zinc-200' },
    { id: 'bg-rose-50', label: 'Rosa' , class: 'bg-rose-50 border-rose-200' },
    { id: 'bg-indigo-50', label: 'Azul', class: 'bg-indigo-50 border-indigo-200' },
    { id: 'bg-amber-50', label: 'Crema', class: 'bg-amber-50 border-amber-200' },
    { id: 'bg-emerald-50', label: 'Verde', class: 'bg-emerald-50 border-emerald-200' },
  ];

  useEffect(() => {
    // Load preference from local storage
    const saved = localStorage.getItem(`chat_bg_${matchId}`);
    if (saved) setBgColor(saved);
  }, [matchId]);

  const handleSetBgColor = (color: string) => {
    setBgColor(color);
    localStorage.setItem(`chat_bg_${matchId}`, color);
    setShowColorPicker(false);
  };

  useEffect(() => {
    if (!matchId || !user) return;

    // Fetch other user info
    const fetchOtherUser = async () => {
      const matchDoc = await getDoc(doc(db, 'matches', matchId));
      if (matchDoc.exists()) {
        const uids = matchDoc.data().uids;
        const otherUid = uids.find((id: string) => id !== user.uid);
        if (otherUid) {
          const userDoc = await getDoc(doc(db, 'users', otherUid));
          if (userDoc.exists()) setOtherUser(userDoc.data());
        }
      }
    };
    fetchOtherUser();

    // Subscribe to messages
    const q = query(
      collection(db, 'matches', matchId, 'messages'),
      orderBy('timestamp', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setMessages(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message)));
      setTimeout(() => {
        scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    });

    // Listen for incoming calls
    const callsQuery = query(
      collection(db, 'matches', matchId, 'calls'),
      where('status', '==', 'requesting'),
      orderBy('createdAt', 'desc'),
      limit(1)
    );

    const unsubscribeCalls = onSnapshot(callsQuery, (snapshot) => {
      if (!snapshot.empty) {
        const callData = snapshot.docs[0].data();
        if (callData.callerUid !== user.uid) {
          setActiveCall({ 
            type: callData.type, 
            isIncoming: true,
            callId: snapshot.docs[0].id
          });
        }
      }
    });

    return () => {
      unsubscribe();
      unsubscribeCalls();
    };
  }, [matchId, user]);

  const handleSendMessage = async (textToSend = newMessage) => {
    if (!textToSend.trim() || !matchId || !user) return;

    try {
      await addDoc(collection(db, 'matches', matchId, 'messages'), {
        senderUid: user.uid,
        text: textToSend,
        timestamp: serverTimestamp()
      });

      await updateDoc(doc(db, 'matches', matchId), {
        lastMessage: textToSend,
        lastMessageAt: serverTimestamp()
      });

      setNewMessage('');
      setSuggestedMessage('');
    } catch (err) {
      console.error('Error sending message:', err);
    }
  };

  const getAiSuggestion = async () => {
    setIsAiSuggesting(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      
      // Get last 10 messages for context
      const chatHistory = messages.slice(-10).map(m => 
        `${m.senderUid === user?.uid ? 'Yo' : otherUser?.displayName}: ${m.text}`
      ).join('\n');

      const prompt = `Estás en una aplicación de citas llamada Cora. Tu nombre es ${user?.displayName}. 
      Estás chateando con ${otherUser?.displayName}.
      
      Perfil de ${otherUser?.displayName}:
      Bio: "${otherUser?.bio}"
      Edad: ${otherUser?.age}
      
      ${chatHistory ? `Historial reciente de la conversación:\n${chatHistory}\n` : 'Aún no han empezado a hablar.'}
      
      Basado en esto, sugiere ${chatHistory ? 'una respuesta natural y encantadora' : 'un rompehielos creativo y respetuoso'} en español que mantenga el interés.
      Responde SOLO con el mensaje sugerido, sin comillas ni explicaciones.`;
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt
      });
      
      setSuggestedMessage(response.text || '');
    } catch (err) {
      console.error('AI error:', err);
    } finally {
      setIsAiSuggesting(false);
    }
  };

  const formatMessageDate = (timestamp: any) => {
    if (!timestamp) return '';
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const oneDay = 24 * 60 * 60 * 1000;

    if (diff < oneDay && now.getDate() === date.getDate()) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    if (diff < 2 * oneDay && now.getDate() !== date.getDate()) {
      return 'Ayer ' + date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    return date.toLocaleDateString([], { day: 'numeric', month: 'short' });
  };

  const shouldShowDateSeparator = (index: number) => {
    if (index === 0) return true;
    const currentMsg = messages[index];
    const prevMsg = messages[index - 1];
    if (!currentMsg.timestamp || !prevMsg.timestamp) return false;
    
    const currentDate = currentMsg.timestamp.toDate ? currentMsg.timestamp.toDate() : new Date(currentMsg.timestamp);
    const prevDate = prevMsg.timestamp.toDate ? prevMsg.timestamp.toDate() : new Date(prevMsg.timestamp);
    
    return currentDate.toDateString() !== prevDate.toDateString();
  };

  const getSeparatorLabel = (timestamp: any) => {
    if (!timestamp) return '';
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    const now = new Date();
    if (date.toDateString() === now.toDateString()) return 'Hoy';
    const yesterday = new Date(now);
    yesterday.setDate(now.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) return 'Ayer';
    return date.toLocaleDateString('es-ES', { day: 'numeric', month: 'long', year: 'numeric' });
  };

  return (
    <div className={`flex flex-col h-screen transition-colors duration-500 ${bgColor}`}>
      {/* Header */}
      <header className="flex items-center justify-between px-4 py-3 border-b border-zinc-100 glass-morphism sticky top-0 z-50 bg-white">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/matches')} className="p-2 -ml-2 text-zinc-400 hover:text-zinc-600 transition-colors">
            <ChevronLeft size={24} />
          </button>
          <div className="flex items-center gap-2">
            <img 
              src={otherUser?.photos?.[0] || `https://api.dicebear.com/7.x/avataaars/svg?seed=${otherUser?.uid}`} 
              alt=""
              className="w-10 h-10 rounded-full object-cover bg-zinc-100"
            />
            <div>
              <h2 className="font-bold leading-tight">{otherUser?.displayName || 'Cargando...'}</h2>
              <p className="text-[10px] text-green-500 font-bold tracking-widest uppercase">En línea</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button 
            onClick={() => setActiveCall({ type: 'voice', isIncoming: false })}
            className="p-2 text-zinc-400 hover:text-brand transition-colors"
          >
            <Phone size={20} />
          </button>
          <button 
            onClick={() => setActiveCall({ type: 'video', isIncoming: false })}
            className="p-2 text-zinc-400 hover:text-brand transition-colors"
          >
            <Video size={20} />
          </button>
          <div className="relative">
            <button 
              onClick={() => setShowColorPicker(!showColorPicker)}
              className={`p-2 rounded-full transition-colors ${showColorPicker ? 'text-brand bg-brand/10' : 'text-zinc-400 hover:text-zinc-600'}`}
            >
              <MoreVertical size={20} />
            </button>

          <AnimatePresence>
            {showColorPicker && (
              <>
                <div 
                  className="fixed inset-0 z-40" 
                  onClick={() => setShowColorPicker(false)} 
                />
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 10, scale: 0.95 }}
                  className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-xl border border-zinc-100 p-4 z-50"
                >
                  <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-3 text-center">Fondo del Chat</p>
                  <div className="grid grid-cols-3 gap-2">
                    {colors.map((c) => (
                      <button
                        key={c.id}
                        onClick={() => handleSetBgColor(c.id)}
                        className={`w-10 h-10 rounded-full border-2 transition-all ${c.class} ${bgColor === c.id ? 'scale-110 ring-2 ring-brand ring-offset-2' : 'hover:scale-105'}`}
                        title={c.label}
                      />
                    ))}
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </div>
      </div>
    </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 pt-6">
        {messages.length === 0 && !otherUser ? (
          <div className="flex flex-col items-center justify-center h-full text-zinc-400 space-y-4">
             <div className="w-16 h-16 bg-zinc-100 rounded-full flex items-center justify-center animate-pulse">
                <MessageCircle size={32} />
             </div>
             <p className="text-sm font-medium">Iniciando conversación...</p>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-zinc-400 space-y-4">
             <div className="w-20 h-20 relative">
               <img 
                 src={otherUser?.photos?.[0] || `https://api.dicebear.com/7.x/avataaars/svg?seed=${otherUser?.uid}`} 
                 className="w-full h-full rounded-full object-cover grayscale opacity-50"
                 alt=""
               />
               <motion.div 
                 animate={{ scale: [1, 1.2, 1], opacity: [0.5, 1, 0.5] }}
                 transition={{ repeat: Infinity, duration: 2 }}
                 className="absolute -bottom-1 -right-1 bg-brand text-white p-1.5 rounded-full"
               >
                 <Sparkles size={14} fill="currentColor" />
               </motion.div>
             </div>
             <div className="text-center">
               <p className="text-sm font-bold text-zinc-600">¡Es un Match!</p>
               <p className="text-xs text-zinc-400 mt-1 max-w-[200px]">Di algo interesante para empezar a conocer a {otherUser?.displayName}.</p>
             </div>
          </div>
        ) : (
          messages.map((msg, idx) => (
            <React.Fragment key={msg.id}>
              {shouldShowDateSeparator(idx) && (
                <div className="flex justify-center my-6">
                  <span className="px-3 py-1 bg-zinc-200/50 backdrop-blur-sm text-[10px] font-bold text-zinc-500 rounded-full uppercase tracking-widest">
                    {getSeparatorLabel(msg.timestamp)}
                  </span>
                </div>
              )}
              <div 
                className={`flex ${msg.senderUid === user?.uid ? 'justify-end' : 'justify-start'}`}
              >
                <div className={`flex flex-col ${msg.senderUid === user?.uid ? 'items-end' : 'items-start'} max-w-[80%]`}>
                  <div 
                    className={`px-4 py-3 rounded-2xl shadow-sm ${
                      msg.senderUid === user?.uid 
                        ? 'bg-brand text-white rounded-br-none shadow-brand/10' 
                        : `${bgColor === 'bg-white' ? 'bg-zinc-100' : 'bg-white'} text-zinc-900 rounded-bl-none`
                    }`}
                  >
                    <p className="text-sm leading-relaxed">{msg.text}</p>
                  </div>
                  <span className="text-[9px] text-zinc-400 mt-1 font-medium px-1">
                    {formatMessageDate(msg.timestamp)}
                  </span>
                </div>
              </div>
            </React.Fragment>
          ))
        )}
        <div ref={scrollRef} />
      </div>

      {/* AI Suggestion */}
      <AnimatePresence>
        {suggestedMessage && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="px-4 py-3 mx-4 mb-2 bg-brand/5 border border-brand/10 rounded-2xl flex items-start gap-3"
          >
            <div className="mt-1 text-brand">
              <Sparkles size={16} />
            </div>
            <div className="flex-1">
              <p className="text-xs font-bold text-brand uppercase tracking-wider mb-1">
                {messages.length > 0 ? 'Sugerencia de respuesta' : 'Sugerencia de rompehielos'}
              </p>
              <p className="text-sm text-zinc-600 italic">"{suggestedMessage}"</p>
              <div className="flex gap-2 mt-2">
                <button 
                  onClick={() => handleSendMessage(suggestedMessage)}
                  className="text-xs font-bold text-brand hover:underline"
                >
                  Usar
                </button>
                <button 
                  onClick={() => setSuggestedMessage('')}
                  className="text-xs font-bold text-zinc-400 hover:underline"
                >
                  Descartar
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Input */}
      <div className="p-4 border-t border-zinc-100 pb-8 md:pb-4">
        <div className="flex items-center gap-2 bg-zinc-100 rounded-2xl px-4 py-2">
          <button 
            disabled={isAiSuggesting}
            onClick={getAiSuggestion}
            className="p-2 text-brand hover:bg-brand/10 rounded-full transition-colors disabled:opacity-50"
          >
            <Sparkles size={20} />
          </button>
          <input 
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()}
            placeholder="Escribe un mensaje..."
            className="flex-1 bg-transparent py-2 outline-none text-sm placeholder:text-zinc-400"
          />
          <button className="p-2 text-zinc-400">
            <Smile size={20} />
          </button>
          <button 
            onClick={() => handleSendMessage()}
            disabled={!newMessage.trim()}
            className="p-2 text-brand disabled:opacity-30 disabled:grayscale transition-all active:scale-95"
          >
            <Send size={20} />
          </button>
        </div>
      </div>
      {/* Call Overlay */}
      <AnimatePresence>
        {activeCall && matchId && user && otherUser && (
          <CallOverlay 
            matchId={matchId}
            user={user}
            otherUser={otherUser}
            type={activeCall.type}
            isIncoming={activeCall.isIncoming}
            callId={activeCall.callId}
            onClose={() => setActiveCall(null)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
