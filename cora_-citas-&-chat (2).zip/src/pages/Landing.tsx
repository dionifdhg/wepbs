import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Sparkles, Shield, Zap, Mail, Lock, User, ArrowRight, Eye, EyeOff } from 'lucide-react';
import { Navigate } from 'react-router-dom';

export default function Landing() {
  const { user, profile, signIn, signInWithEmail, signUpWithEmail, loading } = useAuth();
  const [showEmailForm, setShowEmailForm] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (user && profile) return <Navigate to="/discover" />;
  if (user && !profile) return <Navigate to="/onboarding" />;

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      if (isSignUp) {
        await signUpWithEmail(email, password);
      } else {
        await signInWithEmail(email, password);
      }
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/email-already-in-use') {
        setError('Este correo ya está en uso.');
      } else if (err.code === 'auth/invalid-email') {
        setError('El correo no es válido.');
      } else if (err.code === 'auth/weak-password') {
        setError('La contraseña debe tener al menos 6 caracteres.');
      } else if (err.code === 'auth/invalid-credential') {
        setError('Credenciales inválidas.');
      } else {
        setError('Ocurrió un error. Inténtalo de nuevo.');
      }
    }
  };

  return (
    <div className="min-h-screen bg-white text-zinc-900 overflow-hidden relative">
      <AnimatePresence>
        {loading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-white/80 backdrop-blur-sm z-[100] flex flex-col items-center justify-center"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
              className="w-12 h-12 border-4 border-brand border-t-transparent rounded-full mb-4"
            />
            <p className="text-zinc-600 font-medium font-display">Iniciando sesión...</p>
            <p className="text-zinc-400 text-xs mt-2">Revisa si hay una ventana emergente bloqueada</p>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Video Background */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-20 pointer-events-none">
        <video
          autoPlay
          muted
          loop
          playsInline
          className="absolute min-w-full min-h-full object-cover opacity-20 filter grayscale-[20%]"
        >
          <source src="https://assets.mixkit.co/videos/preview/mixkit-loving-couple-sitting-on-a-bench-in-a-park-1100-large.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-white/40 backdrop-blur-[2px]" />
      </div>

      {/* Background blobs */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none">
        <motion.div
          animate={{
            x: [0, 100, 0],
            y: [0, 50, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute -top-20 -left-20 w-[500px] h-[500px] bg-brand/10 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            x: [0, -100, 0],
            y: [0, -50, 0],
            scale: [1, 1.1, 1],
          }}
          transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          className="absolute top-1/2 -right-20 w-[400px] h-[400px] bg-brand-secondary/10 rounded-full blur-3xl"
        />
      </div>

      <main className="max-w-7xl mx-auto px-6 pt-20 pb-12 flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-2 mb-8"
        >
          <div className="w-10 h-10 bg-brand rounded-xl flex items-center justify-center text-white shadow-lg shadow-brand/20">
            <Sparkles fill="currentColor" size={20} />
          </div>
          <span className="text-2xl font-display font-bold tracking-tighter">Cora</span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="text-5xl md:text-7xl font-display font-bold leading-[0.9] mb-6 max-w-3xl"
        >
          Habla, liga <br />
          <span className="text-brand">y conoce gente.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-zinc-500 text-lg md:text-xl max-w-xl mb-12"
        >
          La plataforma de citas diseñada para personas que buscan conexiones reales impulsadas por intereses compartidos y IA inteligente.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="w-full max-w-sm"
        >
          <AnimatePresence mode="wait">
            {!showEmailForm ? (
              <motion.div
                key="selection"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="flex flex-col gap-4"
              >
                <button
                  onClick={signIn}
                  className="group relative w-full px-8 py-4 bg-zinc-900 text-white rounded-2xl font-semibold text-lg overflow-hidden transition-all active:scale-95 flex items-center justify-center gap-3"
                >
                  <div className="absolute inset-0 bg-brand translate-y-full group-hover:translate-y-0 transition-transform duration-300 -z-10" />
                  <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05" />
                    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
                  </svg>
                  Continuar con Google
                </button>

                <div className="flex items-center gap-4 my-2">
                  <div className="h-px bg-zinc-200 flex-1" />
                  <span className="text-zinc-400 text-sm font-medium">o con correo</span>
                  <div className="h-px bg-zinc-200 flex-1" />
                </div>

                <button
                  onClick={() => setShowEmailForm(true)}
                  className="w-full px-8 py-4 bg-white border-2 border-zinc-100 text-zinc-600 rounded-2xl font-semibold text-lg transition-all hover:border-brand hover:text-brand active:scale-95 flex items-center justify-center gap-3"
                >
                  <Mail size={20} />
                  Usar correo electrónico
                </button>
              </motion.div>
            ) : (
              <motion.div
                key="email-form"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="bg-white p-2"
              >
                <form onSubmit={handleEmailAuth} className="space-y-4">
                  <div className="space-y-1.5 text-left">
                    <label className="text-sm font-bold text-zinc-700 ml-1">Correo electrónico</label>
                    <div className="relative">
                      <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                      <input 
                        type="email"
                        required
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="tu@email.com"
                        className="w-full pl-12 pr-4 py-3.5 bg-zinc-50 border-2 border-zinc-100 rounded-2xl focus:border-brand focus:ring-0 outline-none transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5 text-left">
                    <label className="text-sm font-bold text-zinc-700 ml-1">Contraseña</label>
                    <div className="relative">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" size={18} />
                      <input 
                        type={showPassword ? "text" : "password"}
                        required
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="••••••••"
                        className="w-full pl-12 pr-12 py-3.5 bg-zinc-50 border-2 border-zinc-100 rounded-2xl focus:border-brand focus:ring-0 outline-none transition-all"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600"
                      >
                        {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                      </button>
                    </div>
                  </div>

                  {error && (
                    <motion.p 
                      initial={{ opacity: 0, y: -10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-rose-500 text-sm font-medium px-1"
                    >
                      {error}
                    </motion.p>
                  )}

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full py-4 bg-brand text-white rounded-2xl font-bold text-lg shadow-lg shadow-brand/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2 mt-2"
                  >
                    {isSignUp ? 'Crear cuenta' : 'Iniciar sesión'}
                    <ArrowRight size={20} />
                  </button>

                  <div className="flex flex-col gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setIsSignUp(!isSignUp)}
                      className="text-sm text-zinc-500 hover:text-brand transition-colors font-medium"
                    >
                      {isSignUp ? '¿Ya tienes cuenta? Inicia sesión' : '¿No tienes cuenta? Regístrate'}
                    </button>
                    <button
                      type="button"
                      onClick={() => setShowEmailForm(false)}
                      className="text-sm text-zinc-400 hover:text-zinc-600 transition-colors"
                    >
                      Volver atrás
                    </button>
                  </div>
                </form>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Features Preview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-24 w-full">
          {[
            { icon: Sparkles, title: "IA de Conexión", desc: "Nuestro algoritmo entiende qué te hace vibrar." },
            { icon: Shield, title: "Seguro & Privado", desc: "Tus datos siempre están protegidos con nosotros." },
            { icon: Zap, title: "Chat Fluido", desc: "Mensajería en tiempo real sin interrupciones." },
          ].map((feature, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + i * 0.1 }}
              className="p-8 rounded-3xl bg-zinc-50 border border-zinc-100 text-left"
            >
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-brand shadow-sm mb-6">
                <feature.icon size={24} />
              </div>
              <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
              <p className="text-zinc-500 leading-relaxed">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </main>

      {/* Footer Decoration */}
      <div className="mt-auto pt-20 flex justify-center pb-8 opacity-20 filter grayscale">
        <div className="flex -space-x-4">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="w-12 h-12 rounded-full bg-zinc-200 border-2 border-white" />
          ))}
        </div>
      </div>
    </div>
  );
}
