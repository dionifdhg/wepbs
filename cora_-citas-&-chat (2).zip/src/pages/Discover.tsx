import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../context/AuthContext';
import { collection, query, where, getDocs, addDoc, serverTimestamp, doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { motion, AnimatePresence, useMotionValue, useTransform } from 'motion/react';
import { Heart, X, Info, Sparkles, RefreshCcw, Search, Sliders, ChevronLeft, ChevronRight, Share2, ChevronDown, ChevronUp } from 'lucide-react';

interface UserProfile {
  uid: string;
  displayName: string;
  age: number;
  bio: string;
  photos: string[];
  gender: string;
  interestedIn: string;
  location?: string;
}

export default function Discover() {
  const { user, profile } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedUserForDetails, setSelectedUserForDetails] = useState<UserProfile | null>(null);
  const [swipedInSession, setSwipedInSession] = useState<Set<string>>(new Set());
  
  // Filters state
  const [filters, setFilters] = useState({
    minAge: 18,
    maxAge: 50,
    gender: 'both', // male, female, both
    location: ''
  });

  // Load defaults from profile
  useEffect(() => {
    if (profile) {
      setFilters(prev => ({
        ...prev,
        gender: profile.interestedIn || 'both'
      }));
    }
  }, [profile]);
  const [shareStatus, setShareStatus] = useState<string | null>(null);

  useEffect(() => {
    if (shareStatus) {
      const timer = setTimeout(() => setShareStatus(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [shareStatus]);

  const handleShare = (targetUser: UserProfile) => {
    // Fictional sharing logic
    const profileUrl = `https://spark.dating/profile/${targetUser.uid}`;
    
    // Attempt to use the clipboard API
    if (navigator.clipboard) {
      navigator.clipboard.writeText(profileUrl).then(() => {
        setShareStatus(`¡Enlace de ${targetUser.displayName} copiado!`);
      }).catch(() => {
        setShareStatus('Función de compartir en desarrollo...');
      });
    } else {
      setShareStatus('Función de compartir en desarrollo...');
    }
  };

  useEffect(() => {
    const fetchUsers = async () => {
      if (!user) return;
      setLoading(true);
      try {
        const q = query(collection(db, 'users'), where('uid', '!=', user.uid));
        const querySnapshot = await getDocs(q);
        const data = querySnapshot.docs.map(doc => doc.data() as UserProfile);
        
        const swipedQuery = query(collection(db, 'swipes'), where('fromUid', '==', user.uid));
        const swipedSnapshot = await getDocs(swipedQuery);
        const swipedIds = new Set(swipedSnapshot.docs.map(d => d.data().toUid));
        
        const finalUsers = data.filter(u => !swipedIds.has(u.uid));
        setUsers(finalUsers);
      } catch (err) {
        console.error('Error fetching users:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchUsers();
  }, [user]);

  const filteredUsers = useMemo(() => {
    return users.filter(u => {
      // Don't show users swiped in this session
      if (swipedInSession.has(u.uid)) return false;

      const ageMatch = u.age >= filters.minAge && u.age <= filters.maxAge;
      const genderMatch = filters.gender === 'both' || u.gender === filters.gender;
      const locationMatch = !filters.location || (u.location?.toLowerCase().includes(filters.location.toLowerCase()));
      return ageMatch && genderMatch && locationMatch;
    });
  }, [users, filters, swipedInSession]);

  const handleSwipe = async (type: 'like' | 'pass', targetUser: UserProfile) => {
    if (!user) return;
    
    // Optimistically update session state to hide the user immediately
    setSwipedInSession(prev => {
      const next = new Set(prev);
      next.add(targetUser.uid);
      return next;
    });

    try {
      await addDoc(collection(db, 'swipes'), {
        fromUid: user.uid,
        toUid: targetUser.uid,
        type,
        timestamp: serverTimestamp()
      });

      if (type === 'like') {
        const q = query(
          collection(db, 'swipes'), 
          where('fromUid', '==', targetUser.uid),
          where('toUid', '==', user.uid),
          where('type', '==', 'like')
        );
        const matchSnapshot = await getDocs(q);
        
        if (!matchSnapshot.empty) {
          const matchId = [user.uid, targetUser.uid].sort().join('_');
          await setDoc(doc(db, 'matches', matchId), {
            uids: [user.uid, targetUser.uid],
            createdAt: serverTimestamp(),
            lastMessage: '¡Habéis hecho match!',
            lastMessageAt: serverTimestamp()
          });
          alert('¡Es un Match! 🎉');
        }
      }
      
      setCurrentIndex(0); // With session-aware filtering, we just stay at 0 as users are removed from list
      setSelectedUserForDetails(null);
    } catch (err) {
      console.error('Error swiping:', err);
    }
  };

  const seedUsers = async () => {
    if (!user) return;
    setLoading(true);
    const demoUsers = [
      {
        uid: 'demo1',
        displayName: 'Elena',
        age: 24,
        bio: 'Amante de la fotografía y los viajes espontáneos. Busco a alguien para compartir un buen café y risas.',
        photos: ['https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=600'],
        gender: 'female',
        interestedIn: 'male',
        location: 'Madrid, ES'
      },
      {
        uid: 'demo2',
        displayName: 'Marcos',
        age: 28,
        bio: 'Arquitecto, deportista y cocinero aficionado. Me encanta el senderismo y perdernos por la ciudad.',
        photos: ['https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=600'],
        gender: 'male',
        interestedIn: 'female',
        location: 'Barcelona, ES'
      },
      {
        uid: 'demo3',
        displayName: 'Lucía',
        age: 22,
        bio: 'Estudiante de artes visuales. Siempre con un pincel en la mano. Me gustan los planes tranquilos y la buena música.',
        photos: ['https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=600'],
        gender: 'female',
        interestedIn: 'both',
        location: 'Valencia, ES'
      },
      {
        uid: 'demo4',
        displayName: 'Carlos',
        age: 31,
        bio: 'Desarrollador de software. Geek de corazón. Busco a alguien con quien debatir sobre tecnología y el sentido de la vida.',
        photos: ['https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=600'],
        gender: 'male',
        interestedIn: 'female',
        location: 'Sevilla, ES'
      }
    ];

    try {
      for (const u of demoUsers) {
        await setDoc(doc(db, 'users', u.uid), u);
      }
      const q = query(collection(db, 'users'), where('uid', '!=', user.uid));
      const querySnapshot = await getDocs(q);
      const data = querySnapshot.docs.map(doc => doc.data() as UserProfile);
      setUsers(data);
    } catch (err) {
      console.error('Error seeding users:', err);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center">
      <RefreshCcw className="animate-spin text-brand" size={32} />
    </div>
  );

  const currentUserToView = filteredUsers[currentIndex];

  return (
    <div className="max-w-xl mx-auto px-4 py-8 h-[calc(100vh-80px)] flex flex-col items-center relative">
      {/* Share Alert */}
      <AnimatePresence>
        {shareStatus && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="fixed bottom-24 left-1/2 -translate-x-1/2 z-[200] bg-zinc-900 text-white px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-3 whitespace-nowrap"
          >
            <Share2 size={18} className="text-brand" />
            <span className="text-sm font-medium">{shareStatus}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="w-full flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold font-display">Descubrir</h1>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1 text-brand">
            <Sparkles size={20} />
            <span className="text-sm font-bold">Smart Match</span>
          </div>
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className={`p-2 rounded-full transition-colors ${showFilters ? 'bg-brand text-white' : 'bg-zinc-100 text-zinc-600'}`}
          >
            <Sliders size={20} />
          </button>
        </div>
      </div>

      {/* Filters Overlay */}
      <AnimatePresence>
        {showFilters && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowFilters(false)}
              className="fixed inset-0 bg-black/40 backdrop-blur-sm z-[100]"
            />
            <motion.div 
              initial={{ opacity: 0, y: 100, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 100, scale: 0.95 }}
              className="fixed bottom-0 inset-x-0 glass-morphism p-8 rounded-t-[3rem] z-[101] space-y-8 shadow-2xl border-t border-white/20 pb-12 max-w-xl mx-auto"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-black italic uppercase tracking-tight">Filtros de Búsqueda</h2>
                <button 
                  onClick={() => setShowFilters(false)}
                  className="w-10 h-10 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-500"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="space-y-4">
                <label className="text-xs font-bold uppercase tracking-[0.2em] text-zinc-400">Interesado en</label>
                <div className="flex p-1 bg-zinc-100 rounded-2xl">
                  {[
                    { id: 'male', label: 'Hombres' },
                    { id: 'female', label: 'Mujeres' },
                    { id: 'both', label: 'Ambos' }
                  ].map((g) => (
                    <button
                      key={g.id}
                      onClick={() => setFilters({ ...filters, gender: g.id })}
                      className={`flex-1 py-3 rounded-xl text-xs font-black uppercase tracking-tight transition-all ${
                        filters.gender === g.id 
                          ? 'bg-white text-zinc-900 shadow-sm' 
                          : 'text-zinc-500 hover:text-zinc-700'
                      }`}
                    >
                      {g.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center mb-2">
                  <label className="text-xs font-bold uppercase tracking-[0.2em] text-zinc-400">Rango de Edad</label>
                  <span className="text-sm font-black italic bg-brand/10 text-brand px-3 py-1 rounded-full">
                    {filters.minAge} — {filters.maxAge}
                  </span>
                </div>
                
                <div className="space-y-6 px-1">
                  <div className="relative h-2 bg-zinc-100 rounded-full">
                    <div 
                      className="absolute h-full bg-brand rounded-full" 
                      style={{ 
                        left: `${((filters.minAge - 18) / (80 - 18)) * 100}%`,
                        right: `${100 - ((filters.maxAge - 18) / (80 - 18)) * 100}%`
                      }} 
                    />
                    <input 
                      type="range" 
                      min="18" 
                      max="80" 
                      value={filters.minAge}
                      onChange={(e) => setFilters({ ...filters, minAge: Math.min(parseInt(e.target.value), filters.maxAge - 1) })}
                      className="absolute inset-0 w-full appearance-none bg-transparent pointer-events-none [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:h-6 [&::-webkit-slider-thumb]:w-6 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-brand [&::-webkit-slider-thumb]:ring-4 [&::-webkit-slider-thumb]:ring-white [&::-webkit-slider-thumb]:shadow-lg"
                    />
                    <input 
                      type="range" 
                      min="18" 
                      max="80" 
                      value={filters.maxAge}
                      onChange={(e) => setFilters({ ...filters, maxAge: Math.max(parseInt(e.target.value), filters.minAge + 1) })}
                      className="absolute inset-0 w-full appearance-none bg-transparent pointer-events-none [&::-webkit-slider-thumb]:pointer-events-auto [&::-webkit-slider-thumb]:h-6 [&::-webkit-slider-thumb]:w-6 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-brand [&::-webkit-slider-thumb]:ring-4 [&::-webkit-slider-thumb]:ring-white [&::-webkit-slider-thumb]:shadow-lg"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-xs font-bold uppercase tracking-[0.2em] text-zinc-400">Ciudad o País</label>
                <div className="relative">
                  <input 
                    type="text"
                    placeholder="Eje: Madrid, Barcelona..."
                    value={filters.location}
                    onChange={(e) => setFilters({ ...filters, location: e.target.value })}
                    className="w-full p-4 bg-zinc-50 border border-zinc-100 rounded-2xl outline-none focus:border-brand text-sm font-bold placeholder:text-zinc-300 transition-all"
                  />
                  <Search size={18} className="absolute right-4 top-4 text-zinc-300" />
                </div>
              </div>

              <div className="flex gap-4">
                <button 
                  onClick={() => {
                    setFilters({
                      minAge: 18,
                      maxAge: 50,
                      gender: profile?.interestedIn || 'both',
                      location: ''
                    });
                  }}
                  className="flex-1 py-4 bg-zinc-100 text-zinc-600 rounded-2xl font-black uppercase text-xs tracking-widest active:scale-95 transition-all"
                >
                  Restablecer
                </button>
                <button 
                  onClick={() => setShowFilters(false)}
                  className="flex-[2] py-4 bg-zinc-900 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-zinc-900/20 active:scale-95 transition-all"
                >
                  Aplicar Filtros
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <div className="relative flex-1 w-full max-h-[600px]">
        <AnimatePresence>
          {currentUserToView ? (
            <SwipeCard 
              key={currentUserToView.uid}
              userProfile={currentUserToView}
              onSwipe={(type) => handleSwipe(type, currentUserToView)}
              onOpenDetails={() => setSelectedUserForDetails(currentUserToView)}
              onShare={() => handleShare(currentUserToView)}
            />
          ) : (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="absolute inset-0 flex flex-col items-center justify-center text-center p-8 bg-white border border-dashed border-zinc-200 rounded-3xl"
            >
              <div className="w-20 h-20 bg-zinc-100 rounded-full flex items-center justify-center text-zinc-400 mb-4">
                <Search size={32} />
              </div>
              <h2 className="text-lg font-bold">No hay más personas cerca</h2>
              <p className="text-zinc-500 text-sm mb-6">Prueba a profundizar tus preferencias o vuelve más tarde.</p>
              <button 
                onClick={seedUsers}
                className="px-6 py-2 bg-brand/10 text-brand rounded-xl font-bold text-sm hover:bg-brand/20 transition-colors"
              >
                Cargar Usuarios Demo
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {currentUserToView && (
        <div className="flex items-center gap-6 mt-12 pb-8">
          <button 
            onClick={() => handleSwipe('pass', currentUserToView)}
            className="w-16 h-16 bg-white border border-zinc-100 rounded-full flex items-center justify-center text-zinc-400 shadow-lg hover:text-red-500 transition-colors active:scale-95"
          >
            <X size={32} />
          </button>
          <motion.button 
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            animate={{ 
              boxShadow: ["0px 10px 30px rgba(120, 51, 255, 0.2)", "0px 10px 40px rgba(120, 51, 255, 0.4)", "0px 10px 30px rgba(120, 51, 255, 0.2)"] 
            }}
            transition={{ duration: 2, repeat: Infinity }}
            onClick={() => handleSwipe('like', currentUserToView)}
            className="w-20 h-20 bg-brand text-white rounded-full flex items-center justify-center shadow-xl active:scale-95 transition-transform"
          >
            <Heart fill="white" size={40} />
          </motion.button>
        </div>
      )}

      {/* Detailed User Profile View Overlay */}
      <AnimatePresence>
        {selectedUserForDetails && (
          <DetailedProfileView 
            userProfile={selectedUserForDetails}
            onClose={() => setSelectedUserForDetails(null)}
            onSwipe={(type) => handleSwipe(type, selectedUserForDetails)}
            onShare={() => handleShare(selectedUserForDetails)}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

interface SwipeCardProps {
  userProfile: UserProfile;
  onSwipe: (type: 'like' | 'pass') => void | Promise<void>;
  onOpenDetails: () => void;
  onShare: () => void;
  key?: string | number;
}

function SwipeCard({ userProfile, onSwipe, onOpenDetails, onShare }: SwipeCardProps) {
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-200, 200], [-30, 30]);
  const opacity = useTransform(x, [-200, -150, 0, 150, 200], [0, 1, 1, 1, 0]);

  const handleDragEnd = (_: any, info: any) => {
    if (info.offset.x > 100) onSwipe('like');
    else if (info.offset.x < -100) onSwipe('pass');
  };

  return (
    <motion.div
      style={{ x, rotate, opacity }}
      drag="x"
      dragConstraints={{ left: 0, right: 0 }}
      onDragEnd={handleDragEnd}
      whileHover={{ scale: 1.02 }}
      transition={{ type: 'spring', damping: 20, stiffness: 300 }}
      className="absolute inset-0 cursor-grab active:cursor-grabbing"
      onClick={onOpenDetails}
    >
      <div className="relative w-full h-full rounded-2xl md:rounded-3xl overflow-hidden bg-zinc-200 swipe-card-shadow">
        <img 
          src={userProfile.photos?.[0] || `https://api.dicebear.com/7.x/avataaars/svg?seed=${userProfile.uid}`} 
          alt={userProfile.displayName}
          className="w-full h-full object-cover pointer-events-none"
        />
        
        <div className="absolute inset-x-0 bottom-0 p-8 bg-gradient-to-t from-black/80 via-black/30 to-transparent text-white pointer-events-none">
          <div className="flex items-baseline gap-2 mb-1">
            <h2 className="text-3xl font-bold">{userProfile.displayName}</h2>
            <span className="text-xl opacity-90">{userProfile.age}</span>
          </div>
          {userProfile.location && (
            <p className="text-xs font-bold uppercase tracking-widest opacity-70 mb-2">{userProfile.location}</p>
          )}
          <p className="text-sm opacity-80 line-clamp-2">{userProfile.bio}</p>
        </div>

        <div className="absolute top-8 right-8 flex gap-2">
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onShare();
            }}
            className="p-2 glass-morphism rounded-full text-white pointer-events-auto cursor-pointer hover:bg-white/20 transition-colors"
          >
            <Share2 size={20} />
          </button>
          <div className="p-2 glass-morphism rounded-full text-zinc-900 pointer-events-auto cursor-pointer">
            <Info size={20} />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function DetailedProfileView({ userProfile, onClose, onSwipe, onShare }: { userProfile: UserProfile, onClose: () => void, onSwipe: (type: 'like' | 'pass') => void, onShare: () => void }) {
  const [currentPhoto, setCurrentPhoto] = useState(0);
  const [isBioExpanded, setIsBioExpanded] = useState(false);
  const photos = userProfile.photos || [];
  const isLongBio = userProfile.bio.length > 120;

  return (
    <motion.div 
      initial={{ y: '100%' }}
      animate={{ y: 0 }}
      exit={{ y: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="fixed inset-0 z-[100] bg-white flex flex-col overflow-hidden"
    >
      <div className="relative w-full aspect-[4/5] bg-zinc-100">
        <AnimatePresence mode="wait">
          <motion.img 
            key={currentPhoto}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            src={photos[currentPhoto] || `https://api.dicebear.com/7.x/avataaars/svg?seed=${userProfile.uid}`} 
            className="w-full h-full object-cover"
          />
        </AnimatePresence>

        {/* Header Overlay */}
        <div className="absolute top-0 inset-x-0 p-4 flex justify-between items-center z-10 glass-morphism border-none bg-gradient-to-b from-black/40 to-transparent">
          <button onClick={onClose} className="p-2 bg-white/20 backdrop-blur-md rounded-full text-white">
            <ChevronLeft size={24} />
          </button>
          <span className="text-white font-bold text-sm">Perfil de {userProfile.displayName}</span>
          <button 
            onClick={onShare}
            className="p-2 bg-white/20 backdrop-blur-md rounded-full text-white"
          >
            <Share2 size={24} />
          </button>
        </div>

        {/* Photo Controls */}
        {photos.length > 1 && (
          <div className="absolute inset-0 flex items-center justify-between px-4 pointer-events-none">
            <button 
              onClick={() => setCurrentPhoto(prev => (prev > 0 ? prev - 1 : photos.length - 1))}
              className="w-10 h-10 bg-black/20 backdrop-blur-md rounded-full text-white pointer-events-auto"
            >
              <ChevronLeft size={24} />
            </button>
            <button 
              onClick={() => setCurrentPhoto(prev => (prev < photos.length - 1 ? prev + 1 : 0))}
              className="w-10 h-10 bg-black/20 backdrop-blur-md rounded-full text-white pointer-events-auto"
            >
              <ChevronRight size={24} />
            </button>
          </div>
        )}

        {/* Indicators */}
        <div className="absolute bottom-4 inset-x-0 flex justify-center gap-1 px-4">
          {photos.map((_, i) => (
            <div key={i} className={`h-1 flex-1 rounded-full transition-all ${i === currentPhoto ? 'bg-white' : 'bg-white/30'}`} />
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-8 space-y-6">
        <div>
          <div className="flex items-center justify-between">
            <h2 className="text-4xl font-display font-bold flex items-center gap-2">
              {userProfile.displayName}, {userProfile.age}
              <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                <span className="text-[10px] text-white font-black">✓</span>
              </div>
            </h2>
            <motion.button 
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => onSwipe('like')}
              className="p-3 bg-brand/10 text-brand rounded-full hover:bg-brand/20 transition-colors"
              title="Dar Like"
            >
              <Heart fill="currentColor" size={24} />
            </motion.button>
          </div>
          <div className="flex items-center gap-3 mt-2">
            <p className="text-zinc-600 font-medium capitalize">{userProfile.gender}</p>
            {userProfile.location && (
              <>
                <div className="w-1 h-1 bg-zinc-300 rounded-full" />
                <p className="text-zinc-500 font-medium">{userProfile.location}</p>
              </>
            )}
          </div>
        </div>

        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase tracking-widest text-zinc-400">Sobre mí</h3>
          <div 
            onClick={() => isLongBio && setIsBioExpanded(!isBioExpanded)}
            className={`group transition-all ${isLongBio ? 'cursor-pointer active:scale-[0.99]' : ''}`}
          >
            <motion.p 
              initial={false}
              animate={{ 
                height: isLongBio && !isBioExpanded ? 64 : 'auto',
              }}
              className="text-zinc-600 leading-relaxed text-lg overflow-hidden"
            >
              {userProfile.bio}
            </motion.p>
            {isLongBio && (
              <div className="flex items-center gap-1 text-brand font-bold text-sm mt-2">
                <span>{isBioExpanded ? 'Ver menos' : 'Ver más'}</span>
                {isBioExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
              </div>
            )}
          </div>
        </div>

        <div className="pt-8 flex items-center justify-center gap-8 border-t border-zinc-100">
          <button 
            onClick={() => onSwipe('pass')}
            className="w-20 h-20 bg-zinc-50 border border-zinc-100 rounded-full flex items-center justify-center text-zinc-400 shadow-sm active:scale-95 transition-transform"
          >
            <X size={40} />
          </button>
          <motion.button 
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            animate={{ 
              scale: [1, 1.05, 1],
            }}
            transition={{ 
              scale: { duration: 2, repeat: Infinity, ease: "easeInOut" }
            }}
            onClick={() => onSwipe('like')}
            className="w-24 h-24 bg-brand text-white rounded-full flex items-center justify-center shadow-2xl shadow-brand/30 active:scale-95 transition-transform"
          >
            <Heart fill="white" size={48} />
          </motion.button>
        </div>
      </div>
    </motion.div>
  );
}
